<?php get_header(); ?> <!-- Lädt den Header des Themes (z.B. <head>, Navigation, etc.) -->

<!-- Hauptbereich der Seite -->
<main id="main" class="site-main">
  <?php
  // Prüft, ob WordPress Inhalte (Posts/Pages) für diese Ansicht hat
  if (have_posts()) :
    // Loop: geht alle gefundenen Inhalte durch (meist genau 1 Seite)
    while (have_posts()) : the_post();
      // Gibt den Inhalt aus dem Editor aus (z.B. Elementor/Block-Editor)
      the_content();
    endwhile;
  endif;
  ?>
</main>

<?php get_footer(); ?> <!-- Lädt den Footer des Themes -->
