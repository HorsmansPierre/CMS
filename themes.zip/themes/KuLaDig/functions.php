<?php
if (!defined('ABSPATH')) exit;

/**
 * Theme Bootstrap
 * - lädt Includes, Shortcodes und registriert globale Hooks/AJAX-Endpoints
 */

/* =====================================================================
   Includes: Basis-Funktionen/Assets/Helper
====================================================================== */
require_once get_template_directory() . '/inc/assets.php';   // CSS/JS Enqueue etc.
require_once get_template_directory() . '/inc/api.php';      // KuLaDig API Client
require_once get_template_directory() . '/inc/helpers.php';  // Helper-Funktionen

/* =====================================================================
   Shortcodes: modular laden (jede Datei registriert ihren Shortcode)
====================================================================== */
$shortcodes = [
  'suche',
  'objekt',
  'hero',
  'empfehlungen',
  'kategorien',
  'karte',
  'newsfeed',
  'mitmachen',
  'hilfe',
  'anmelden',
  'impressum',
  'datenschutz',
  'barrierefreiheit',
];

foreach ($shortcodes as $sc) {
  require_once get_template_directory() . "/inc/shortcodes/{$sc}.php";
}


/* =====================================================================
   AJAX: Warmup Search-Index (baut den Index vorab und cached ihn)
====================================================================== */
add_action('wp_ajax_kuladig_warm_search_index', 'kuladig_warm_search_index');
add_action('wp_ajax_nopriv_kuladig_warm_search_index', 'kuladig_warm_search_index');

function kuladig_warm_search_index() {
  $cache_key = 'kld_search_index_v9'; // gleicher Cache-Key wie in suche.php

  // Wenn bereits vorhanden: sofort fertig
  if (is_array(get_transient($cache_key))) {
    wp_send_json_success(['status' => 'cached']);
  }

  // Index-Funktion muss existieren (kommt aus suche.php)
  if (!function_exists('kuladig_get_search_index')) {
    wp_send_json_error(['status' => 'missing_func'], 500);
  }

  // Index bauen + cachen
  $idx = kuladig_get_search_index();

  wp_send_json_success([
    'status' => 'built',
    'count'  => is_array($idx) ? count($idx) : 0,
  ]);
}

/* =====================================================================
   Frontend Assets: Warmups per Inline-JS
====================================================================== */
add_action('wp_enqueue_scripts', function () {

  /* =========================
     Warmup: Newsfeed (nur Startseite)
     - startet fetch im Idle, damit später schneller gerendert wird
  ========================= */
  if (is_front_page()) {
      /*AJAX = Asynchronous JavaScript and XML*/
    $ajax = admin_url('admin-ajax.php');

    $inline = "(function(){
      const ajax = " . wp_json_encode($ajax) . ";
      const run = () => {
        try { fetch(ajax + '?action=kuladig_warm_newsfeed&limit=10', {
          credentials:'same-origin', cache:'no-store'
        }); } catch(e){}
      };
      if ('requestIdleCallback' in window) requestIdleCallback(run, {timeout: 2000});
      else setTimeout(run, 800);
    })();";

    // an ein garantiert geladenes Script hängen
    wp_add_inline_script('leaflet-js', $inline, 'after');
  }

  /* =========================
     Warmup: Search-Index (nur Startseite)
  ========================= */
  if (is_front_page()) {
      /*AJAX = Asynchronous JavaScript and XML*/
    $ajax = admin_url('admin-ajax.php');

    $inline = "(function(){
      const url = " . wp_json_encode($ajax) . ";
      const run = () => {
        try { fetch(url + '?action=kuladig_warm_search_index', {
          credentials: 'same-origin',
          cache: 'no-store'
        }); } catch(e){}
      };
      if ('requestIdleCallback' in window) requestIdleCallback(run, {timeout: 2000});
      else setTimeout(run, 800);
    })();";

    wp_add_inline_script('leaflet-js', $inline, 'after');
  }
});

/* =====================================================================
   INITIAL: einmalig alle verwendeten Objekt-IDs aus Seiten/Posts sammeln
   - sucht nach Shortcodes wie: [kuladig_objekt id="..."]
====================================================================== */
add_action('init', function () {

  // Schon initialisiert? → nichts tun
  if (get_option('kuladig_used_object_ids_initialized')) {
    return;
  }

  $ids = [];

  // Alle Seiten & Posts durchsuchen
  $pages = get_posts([
    'post_type'      => ['page', 'post'],
    'posts_per_page' => -1,
    'post_status'    => 'publish',
  ]);

  foreach ($pages as $p) {
    if (preg_match_all('/\[kuladig_objekt[^\]]*id=["\']?([\w\-]+)["\']?/i', $p->post_content, $m)) {
      foreach ($m[1] as $id) {
        $ids[] = $id;
      }
    }
  }

  // eindeutige IDs speichern
  $ids = array_values(array_unique($ids));
  if ($ids) {
    update_option('kuladig_used_object_ids', $ids, false);
  }

  // Flag setzen → nie wieder ausführen
  update_option('kuladig_used_object_ids_initialized', 1, false);
});

/* =====================================================================
   Runtime: Objekt-ID registrieren, wenn ein Objekt wirklich aufgerufen wurde
====================================================================== */
function kuladig_register_used_object_id($id) {
  if (!$id) return;

  $ids = get_option('kuladig_used_object_ids', []);
  if (!in_array((string)$id, $ids, true)) {
    $ids[] = (string)$id;
    update_option('kuladig_used_object_ids', $ids, false);
  }
}


/* =====================================================================
   AJAX: Warmup Newsfeed (lädt Items vorab in Cache)
====================================================================== */
add_action('wp_ajax_kuladig_warm_newsfeed', 'kuladig_warm_newsfeed');
add_action('wp_ajax_nopriv_kuladig_warm_newsfeed', 'kuladig_warm_newsfeed');

function kuladig_warm_newsfeed() {
  $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;

  if (!function_exists('kuladig_get_newsfeed_items')) {
    wp_send_json_error(['status' => 'missing_func'], 500);
  }

  $items = kuladig_get_newsfeed_items($limit);

  wp_send_json_success([
    'status' => 'ok',
    'count'  => is_array($items) ? count($items) : 0,
  ]);
}
