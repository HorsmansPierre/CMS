<?php
if (!defined('ABSPATH')) exit;

/**
 * Hilfsfunktionen (Helpers)
 * - mit function_exists() geschützt, damit es bei mehrfachen Includes keine Fatal Errors gibt
 */

/* =====================================================================
   Helper: Erste Bild-URL eines Objekts ermitteln
   - bevorzugt ThumbnailToken (schnell)
   - sonst Detail-API laden und erstes Dokument-Token nehmen (Fallback)
====================================================================== */
if (!function_exists('kuladig_first_image_url')) {
  function kuladig_first_image_url($row) {

    // Ergebnis-URL (leer = kein Bild gefunden)
    $img = '';

    // 1) Schnellster Fall: ThumbnailToken ist schon im Row-Array vorhanden
    if (!empty($row['ThumbnailToken'])) {
      $img = 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($row['ThumbnailToken']);

    // 2) Fallback: Detaildaten laden und erstes Dokument-Token nutzen
    } elseif (function_exists('kuladig_api_get') && !empty($row['Id'])) {

      // Detaildaten per API holen (mit Cache TTL)
      $detail = kuladig_api_get('Objekt/' . $row['Id'], [], 12 * HOUR_IN_SECONDS);

      // Dokumente durchgehen und erstes Token nehmen
      if (!empty($detail['Dokumente']) && is_array($detail['Dokumente'])) {
        foreach ($detail['Dokumente'] as $doc) {
          if (!empty($doc['Token'])) {
            $img = 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($doc['Token']);
            break; // erstes gültiges Bild reicht
          }
        }
      }
    }

    // finale Bild-URL zurückgeben (oder leer)
    return $img;
  }
}


/* =====================================================================
   Helper: Labels/Tags aus Detaildaten sammeln (Themen/Schlagwörter/Kategorien)
   - akzeptiert Strings oder Arrays
   - normalisiert: strip_tags, trim, unique, filter(empty)
====================================================================== */
if (!function_exists('kuladig_extract_labels_from_detail')) {
  function kuladig_extract_labels_from_detail($detail) {

    // Sammel-Array
    $labels = [];

    // Diese Keys werden als “Label-Quellen” akzeptiert
    foreach (['Themen','Thema','Schlagwoerter','Schlagworte','Kategorien','Kategorie'] as $key) {

      // Key nicht vorhanden → nächster
      if (empty($detail[$key])) continue;

      // Array → alle Werte übernehmen
      if (is_array($detail[$key])) {
        $labels = array_merge($labels, $detail[$key]);

      // Single Value → als 1 Element anhängen
      } else {
        $labels[] = $detail[$key];
      }
    }

    // Aufräumen: zu String, HTML entfernen, trimmen, leere raus, Duplikate raus
    $labels = array_map(function ($v) {
      return trim(strip_tags((string)$v));
    }, $labels);

    $labels = array_filter($labels, function ($v) {
      return $v !== '';
    });

    return array_values(array_unique($labels));
  }
}


/**
 * BBCode -> sicheres HTML (für KuLaDig Beschreibung)
 */
if (!function_exists('kuladig_parse_bbcode')) {
  function kuladig_parse_bbcode($text) {

    // Entfernen / vereinfachen
    $text = preg_replace('/\[id=.*?\]\s*\[\/id\]/si', '', $text);
    $text = preg_replace('/\[right\].*?\[\/right\]/si', '', $text);
    $text = preg_replace('/\[a=.*?\](.*?)\[\/a\]/si', '$1', $text);

    // Basic Format
    $text = preg_replace('/\[b\](.*?)\[\/b\]/si', '<strong>$1</strong>', $text);
    $text = preg_replace('/\[i\](.*?)\[\/i\]/si', '<em>$1</em>', $text);

    // Listen
    $text = preg_replace('/\[list\]/i', '<ul>', $text);
    $text = preg_replace('/\[\/list\]/i', '</ul>', $text);
    $text = preg_replace('/\[\*\](.*?)($|\[\*\])/si', '<li>$1</li>', $text);

    // Links
    $text = preg_replace_callback(
      '/\[url=(.*?)\](.*?)\[\/url\]/si',
      fn($m) => '<a href="' . esc_url($m[1]) . '" target="_blank" rel="noopener">' . esc_html($m[2]) . '</a>',
      $text
    );

    // WordPress: Absätze + erlaubtes HTML filtern
    return wpautop(wp_kses_post($text));
  }
}
