<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_newsfeed limit="10" title="Newsfeed"]
 */

/* =====================================================================
   Helper: Placeholder-Bild (fallback, wenn kein Thumbnail vorhanden ist)
====================================================================== */

if (!function_exists('kuladig_newsfeed_placeholder_img')) {
  function kuladig_newsfeed_placeholder_img(): string {
    // Wenn es schon eine globale Placeholder-Funktion aus der Suche gibt -> nutzen
    if (function_exists('kuladig_search_placeholder_img')) {
      return kuladig_search_placeholder_img();
    }

    // Fallback: lokales Placeholder-Bild im Theme
    return get_stylesheet_directory_uri() . '/assets/placeholder.jpg';
  }
}

/* =====================================================================
   Daten holen: Newsfeed-Items (mit Transient Cache)
====================================================================== */

if (!function_exists('kuladig_get_newsfeed_items')) {
  function kuladig_get_newsfeed_items(int $limit = 10): array {

    // Limit absichern (min 1, max 50)
    $limit = max(1, min(50, $limit));

    // Cache-Key abhängig vom Limit (verschiedene Limits = verschiedene Caches)
    $cache_key = 'kld_newsfeed_v4_' . $limit;

    // Wenn Cache vorhanden -> direkt zurück
    $cached = get_transient($cache_key);
    if (is_array($cached)) return $cached;

    /* ---------------------------------------------------------------
       1) Basisliste laden (Master-Liste wie Karte/Suche/...)
       - bevorzugt: kuladig_site_objects()
       - fallback: direkte API-Abfrage (200 neueste Änderungen)
    ---------------------------------------------------------------- */

    if (function_exists('kuladig_site_objects')) {
      $rows = kuladig_site_objects(); // liefert Array von Objekten
    } else {
      $res = kuladig_api_get('Objekt', [
        'Seite'           => 0,
        'Seitengroesse'   => 200,
        'SortierModus'    => 'Aenderungsdatum',
        'Sortierrichtung' => 'Absteigend'
      ], 6 * HOUR_IN_SECONDS);

      $rows = (is_array($res) && !empty($res['Ergebnis']) && is_array($res['Ergebnis']))
        ? $res['Ergebnis']
        : [];
    }

    // Keine Daten -> leeren Cache setzen und beenden (damit nicht ständig neu geladen wird)
    if (empty($rows) || !is_array($rows)) {
      set_transient($cache_key, [], 10 * MINUTE_IN_SECONDS);
      return [];
    }

    /* ---------------------------------------------------------------
       2) Roh-Items bauen (aus Master-Liste)
       - type: "new" wenn im aktuellen Jahr, sonst "updated"
       - desc/thumb: erstmal aus Row (schnell), Detailcall später nur falls nötig
    ---------------------------------------------------------------- */

    $currentYear = date('Y');
    $raw = [];

    foreach ($rows as $obj) {
      if (empty($obj['Id'])) continue;

      // Änderungsdatum als Timestamp
      $datumRaw = $obj['ZuletztGeaendert'] ?? null;
      if (!$datumRaw) continue;

      $ts = strtotime($datumRaw);
      if (!$ts) continue;

      // Typ bestimmen (simpler "neu vs. aktualisiert")
      $type = (date('Y', $ts) === $currentYear) ? 'new' : 'updated';

      // Beschreibung direkt aus Row (falls vorhanden)
      $descPlain = '';
      if (!empty($obj['Beschreibung'])) {
        $descPlain = trim(wp_strip_all_tags((string)$obj['Beschreibung']));
      }

      // Thumbnail direkt aus Row (falls ThumbnailToken vorhanden)
      $thumbUrl = '';
      $hasThumb = false;

      if (!empty($obj['ThumbnailToken'])) {
        $thumbUrl = 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($obj['ThumbnailToken']);
        $hasThumb = true;
      }

      $raw[] = [
        'id'        => (string)$obj['Id'],
        'name'      => $obj['Name'] ?? 'Unbenanntes Objekt',
        'date'      => (int)$ts,
        'type'      => $type,
        'thumbUrl'  => $thumbUrl,
        'has_thumb' => $hasThumb,
        'desc'      => $descPlain,
      ];
    }

    // Sicherheit: nach Datum absteigend sortieren (neueste zuerst)
    usort($raw, fn($a, $b) => $b['date'] <=> $a['date']);

    // Nur die gewünschten Items für den Feed
    $items = array_slice($raw, 0, $limit);

    /* ---------------------------------------------------------------
       3) Detail-Fallback: nur für die limit Items
       - falls Thumbnail ODER Beschreibung fehlt -> Objekt-Detail abrufen
    ---------------------------------------------------------------- */

    foreach ($items as &$it) {
      $needThumb = empty($it['thumbUrl']);
      $needDesc  = empty($it['desc']);

      if (!$needThumb && !$needDesc) continue;

      $detail = kuladig_api_get('Objekt/' . $it['id'], [], 12 * HOUR_IN_SECONDS);
      if (!is_array($detail)) continue;

      // Thumbnail aus Dokumenten holen (Thumbnail3Token)
      if ($needThumb && !empty($detail['Dokumente']) && is_array($detail['Dokumente'])) {
        foreach ($detail['Dokumente'] as $d) {
          if (!empty($d['Thumbnail3Token'])) {
            $it['thumbUrl']  = 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($d['Thumbnail3Token']);
            $it['has_thumb'] = true;
            break;
          }
        }
      }

      // Beschreibung aus Detail-Feldern holen
      if ($needDesc) {
        $cand = '';
        foreach (['Beschreibung', 'Kurzbeschreibung', 'BeschreibungKurz'] as $k) {
          if (!empty($detail[$k])) { $cand = (string)$detail[$k]; break; }
        }
        if ($cand) $it['desc'] = trim(wp_strip_all_tags($cand));
      }
    }
    unset($it);

    // Cache setzen (30 Minuten) und zurückgeben
    set_transient($cache_key, $items, 30 * MINUTE_IN_SECONDS);
    return $items;
  }
}

/* =====================================================================
   Shortcode: Ausgabe (HTML)
====================================================================== */

add_shortcode('kuladig_newsfeed', function ($atts) {

  $a = shortcode_atts([
    'limit' => 10,
    'title' => 'Newsfeed',
  ], $atts);

  $limit = (int)$a['limit'];
  $title = trim((string)$a['title']);

  // Items laden (Cache + API + Fallbacks passieren in der Funktion)
  $items = kuladig_get_newsfeed_items($limit);
  if (!$items) return '<p>Keine aktuellen Einträge vorhanden.</p>';

  // Placeholder falls kein Thumbnail vorhanden ist
  $placeholder = kuladig_newsfeed_placeholder_img();

  ob_start(); ?>

  <!-- Page Head -->
  <div class="kld-page-head">
    <h1 class="kld-page-title">Newsfeed</h1>
  </div>

  <!-- Wrapper (gleicher Look wie Suche) -->
  <div class="kld-search-wrap">

    <!-- Feed Grid -->
    <div class="kuladig-newsfeed">
      <?php foreach ($items as $i): ?>
        <?php
          // Bildquelle: Thumb oder Placeholder
          $imgSrc = !empty($i['thumbUrl']) ? $i['thumbUrl'] : $placeholder;

          // Link zum Objekt (per kuladig_id)
          $url = esc_url(add_query_arg('kuladig_id', $i['id'], home_url('/objekt')));
        ?>

        <div class="kuladig-news-item">
          <div class="kuladig-news-thumb">
            <img src="<?php echo esc_url($imgSrc); ?>" loading="lazy" alt="">
          </div>

          <div>
            <!-- Meta: neu/aktualisiert + Datum -->
            <div class="kuladig-news-meta">
              <span class="kuladig-news-type <?php echo esc_attr($i['type']); ?>">
                <?php echo ($i['type'] === 'new') ? '🆕 Neu' : '✏️ Aktualisiert'; ?>
              </span>
              · <?php echo date('d.m.Y', (int)$i['date']); ?>
            </div>

            <!-- Titel -->
            <h4><?php echo esc_html($i['name'] ?: 'Unbenanntes Objekt'); ?></h4>

            <!-- Beschreibung (gekürzt via CSS clamp) -->
            <?php if (!empty($i['desc'])): ?>
              <p class="kld-desc"><?php echo esc_html($i['desc']); ?></p>
            <?php endif; ?>

            <!-- Action Button -->
            <div class="kld-news-actions">
              <a class="kld-pill-btn kld-pill-sm kld-pill-link" href="<?php echo $url; ?>">
                <span class="kld-pill-left" aria-hidden="true">📄</span>
                <span class="kld-pill-right">
                  <span class="kld-pill-text">Zum Objekt</span>
                  <span class="kld-pill-emoji" aria-hidden="true">↗️</span>
                </span>
              </a>
            </div>

          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <?php
  return ob_get_clean();
});
