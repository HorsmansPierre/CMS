<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_hero]
 * Bootstrap Carousel mit bis zu 5 Slides (aus KuLaDig Master-Liste)
 */
add_shortcode('kuladig_hero', function () {

  // =====================================================================
  // PHP: Slides aus KuLaDig holen (Fallback, wenn nichts gefunden wird)
  // =====================================================================
  $slides = [];

  // Master-Liste (wie Karte/Startseite) -> gecached über kuladig_site_objects()
  $rows = kuladig_site_objects(3 * HOUR_IN_SECONDS);

  if (!empty($rows)) {
    foreach ($rows as $row) {

      // Ohne Objekt-ID kein Link / kein Detail
      if (empty($row['Id'])) continue;

      // Erstes Bild ermitteln (ThumbnailToken oder Detail-Call-Fallback)
      $img = kuladig_first_image_url($row);

      if ($img) {
        $slides[] = [
          'img'   => $img,
          'title' => $row['Name'] ?? '',
          'desc'  => $row['Beschreibung'] ?? '',
          'href'  => home_url('/objektansicht/?kuladig_id=' . urlencode($row['Id'])),
        ];
      }

      // Maximal 5 Slides
      if (count($slides) >= 5) break;
    }
  }

  // Fallback-Slides (wenn API / Bilder leer)
  if (empty($slides)) {
    $slides = [
      [
        'img'   => 'https://images.unsplash.com/photo-1539693010228-32a9af3aa95f?q=80&w=1600&auto=format&fit=crop',
        'title' => 'Friedhöfe in der Bundesstadt Bonn',
        'desc'  => 'Entdecken Sie Geschichte und Kultur im Stadtraum.',
        'href'  => '#',
      ],
      [
        'img'   => 'https://images.unsplash.com/photo-1582589314449-5125cf5e992b?q=80&w=1600&auto=format&fit=crop',
        'title' => 'Museen & Sammlungen neu entdecken',
        'desc'  => 'Aktuelle Ausstellungen, Sammlungen und Highlights.',
        'href'  => '#',
      ],
      [
        'img'   => 'https://images.unsplash.com/photo-1520697222861-e33ff2d88b90?q=80&w=1600&auto=format&fit=crop',
        'title' => 'Historische Stadtansichten',
        'desc'  => 'Vergangenheit im Vergleich zur Gegenwart.',
        'href'  => '#',
      ],
    ];
  }

  ob_start(); ?> <!-- Output-Buffering: HTML/JS sammeln und am Ende als Shortcode-String zurückgeben -->

  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- Hero Carousel Wrapper -->
  <div
    id="kld-hero"
    class="carousel slide mb-4"
    data-bs-ride="carousel"
    data-bs-interval="4500"
    aria-label="Startseiten-Highlights"
  >
    <div class="carousel-inner position-relative">

      <?php foreach ($slides as $i => $s):

        // Sicher ausgeben + Beschreibung kürzen (24 Wörter)
        $title = esc_html($s['title'] ?? '');
        $desc  = esc_html(wp_trim_words(wp_strip_all_tags($s['desc'] ?? ''), 24, ' …'));
        $href  = esc_url($s['href'] ?? '#');
        $img   = esc_url($s['img'] ?? '');

      ?>
        <!-- Slide -->
        <div class="carousel-item <?php echo $i === 0 ? 'active' : ''; ?>">

          <!-- Hintergrundbild (per CSS Background) -->
          <div class="slide-bg" style="background-image:url('<?php echo $img; ?>')"></div>

          <!-- Content-Overlay -->
          <div class="slide-content">
            <div class="container">
              <div class="slide-inner col-12 col-lg-8 kld-hero-content">

                <!-- Titel -->
                <h2 class="display-6 mb-2"><?php echo $title; ?></h2>

                <!-- Beschreibung -->
                <?php if ($desc): ?>
                  <p class="lead mb-3 opacity-75"><?php echo $desc; ?></p>
                <?php endif; ?>

                <!-- CTA Button -->
                <a class="kld-pill-btn" href="<?php echo $href; ?>">
                  <span class="kld-pill-left" aria-hidden="true">✨</span>
                  <span class="kld-pill-right">
                    <span class="kld-pill-text">Mehr</span>
                    <span class="kld-pill-emoji" aria-hidden="true">↗️</span>
                  </span>
                </a>

              </div>
            </div>
          </div>

        </div>
      <?php endforeach; ?>

    </div>

    <!-- Carousel Pfeile -->
    <button class="carousel-control-prev" type="button" data-bs-target="#kld-hero" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#kld-hero" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>

  <!-- =====================================================================
       JavaScript:
  ====================================================================== -->

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      // Hero-Element holen (damit wir nur innerhalb davon arbeiten)
      const hero = document.getElementById('kld-hero');
      if (!hero) return;

      // Alle Content-Container initial "unsichtbar" machen (für Animation)
      hero.querySelectorAll('.kld-hero-content').forEach(el => el.classList.remove('is-visible'));

      // Hilfsfunktion: alle aktiven Content-Container der aktuellen Slide holen
      const getActives = () =>
        hero.querySelectorAll('.carousel-item.active .kld-hero-content');

      // Aktive Slide animieren (Klasse togglen -> CSS Transition/Keyframes)
      function showActive() {
        getActives().forEach(el => {
          el.classList.remove('is-visible'); // Reset
          void el.offsetWidth;               // Reflow -> Animation kann erneut starten
          el.classList.add('is-visible');
        });
      }

      // Fallback ohne IntersectionObserver: sofort animieren
      if (!('IntersectionObserver' in window)) {
        showActive();
      } else {
        // Observer: animiert erst, wenn Hero sichtbar ist (und reset wenn rausgescrollt)
        const io = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              // Rein-scrollen -> aktive Slide animieren
              showActive();
            } else {
              // Raus-scrollen -> reset, damit beim nächsten Rein-scrollen wieder animiert
              hero.querySelectorAll('.kld-hero-content').forEach(el => el.classList.remove('is-visible'));
            }
          });
        }, {
          threshold: 0.25,
          rootMargin: "0px 0px -15% 0px" // stabiler, weniger "flackern"
        });

        io.observe(hero);
      }

      // Bei jedem Slide-Wechsel erneut animieren (Bootstrap Event)
      hero.addEventListener('slid.bs.carousel', () => {
        showActive();
      });
    });
  </script>

  <?php
  return ob_get_clean(); // Gepufferten Output holen, Buffer leeren, als Shortcode-HTML zurückgeben
});
