<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_karte]
 */
add_shortcode('kuladig_karte', function () {

  // =====================================================================
  // PHP: Master-Objektliste holen + Koordinaten in einfache Punkte umwandeln
  // =====================================================================
  $objs = kuladig_site_objects(); // ✅ Master-Liste (z.B. neueste Objekte)

  if (empty($objs)) {
    return '<p>Keine Kartendaten vorhanden.</p>';
  }

  $points = [];
  foreach ($objs as $o) {
    if (empty($o['Punktkoordinate']['coordinates'])) continue;

    $points[] = [
      'id'   => (string) $o['Id'],
      'type' => 'object', // Objekt aus KuLaDig
      'lat'  => $o['Punktkoordinate']['coordinates'][1],
      'lng'  => $o['Punktkoordinate']['coordinates'][0],
    ];
  }

  ob_start(); ?>

  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- Haupt überschrift -->
  <div class="kld-page-head">
    <h1 class="kld-page-title">Karte</h1>
  </div>

  <!-- Map Wrapper: Layout (Sidebar + Karte) -->
  <div class="kuladig-map-wrap">
    <div class="kuladig-layout">

      <!-- Sidebar: Preview + Aktionen -->
      <div>

        <!-- Preview-Box: wird per JS befüllt -->
        <div id="kuladig-preview" class="kuladig-preview">
          <p>Marker anklicken oder auf die Karte klicken.</p>
        </div>

        <!-- Button-Gruppe: Route / Löschen / Custom Marker -->
        <div class="kld-pill-group" style="margin-top:1rem;">
          <button class="kld-pill-btn kld-pill-sm kld-pill-blue" type="button" onclick="openRoute()">
            <span class="kld-pill-left" aria-hidden="true">🧭</span>
            <span class="kld-pill-right">
              <span class="kld-pill-text">Route in Google Maps</span>
              <span class="kld-pill-emoji" aria-hidden="true">↗️</span>
            </span>
          </button>

          <button class="kld-pill-btn kld-pill-sm kld-pill-red" type="button" onclick="clearRoute()">
            <span class="kld-pill-left" aria-hidden="true">🗑️</span>
            <span class="kld-pill-right">
              <span class="kld-pill-text">Komplette Route löschen</span>
              <span class="kld-pill-emoji" aria-hidden="true">⛔</span>
            </span>
          </button>

          <button class="kld-pill-btn kld-pill-sm kld-pill-red" type="button" onclick="removeCustomMarkers()">
            <span class="kld-pill-left" aria-hidden="true">✖️</span>
            <span class="kld-pill-right">
              <span class="kld-pill-text">Eigene Marker entfernen</span>
              <span class="kld-pill-emoji" aria-hidden="true">📍</span>
            </span>
          </button>
        </div>

      </div>

      <!-- Map Container (Leaflet) -->
      <div id="kuladig-map"></div>

    </div>
  </div>

  <!-- =====================================================================
       JavaScript:
  ====================================================================== -->
  <script>
    (function waitForLeaflet() {
      // Leaflet erst starten, wenn L verfügbar ist
      if (typeof L === 'undefined') {
        setTimeout(waitForLeaflet, 100);
        return;
      }

      // -------------------------------------------------------------------
      // Globale Daten / Zustand
      // -------------------------------------------------------------------
      const STORAGE_KEY = 'kuladig_route_final'; // localStorage Key
      const objects = <?php echo wp_json_encode($points); ?>; // PHP -> JS Punkte

      // Globale Variablen (für Buttons / externe Calls nutzbar)
      window.allPoints = [...objects]; // alle Punkte (Objekte + Custom)
      window.selected = [];            // IDs in Reihenfolge (Route)
      window.markerMap = {};           // id -> Leaflet Marker

      // Aktuell ausgewählter Punkt (für Preview/Toggle)
      let activeId = null;

      // -------------------------------------------------------------------
      // Restore: Route + Custom Marker aus localStorage
      // -------------------------------------------------------------------
      try {
        const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
        if (stored) {
          window.selected = stored.selected || [];
          window.allPoints = [...objects, ...(stored.custom || [])];
        }
      } catch (e) {}

      // Ohne Punkte: nichts anzeigen
      if (!window.allPoints.length) return;

      // -------------------------------------------------------------------
      // Map Setup (Leaflet)
      // -------------------------------------------------------------------
      window.kuladigMap = L.map('kuladig-map').setView(
        [window.allPoints[0].lat, window.allPoints[0].lng],
        9
      );

      // Tiles (Open Street Map)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap'
      }).addTo(window.kuladigMap);

      // -------------------------------------------------------------------
      // Persist: Route + Custom Marker speichern
      // -------------------------------------------------------------------
      function save() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          selected: window.selected,
          custom: window.allPoints.filter(p => p.type === 'custom')
        }));
      }

      // -------------------------------------------------------------------
      // Marker Icons (SVG Pins: blau/rot/grün, optional Nummer)
      // -------------------------------------------------------------------

      window.kldCurrentId = window.kldCurrentId || null;

      function icon(index = null, isCurrent = false) {
        const state = isCurrent ? 'green' : (index !== null ? 'red' : 'blue');
        const num   = (index !== null) ? String(index + 1) : '';
        const fs    = (num.length >= 3) ? 9 : (num.length === 2 ? 10 : 11);

        // Rot: weißer Innenkreis
        const redCore = `<circle class="kld-pin-core" cx="18" cy="14.3" r="6.2"></circle>`;

        // Blau/Grün: Loch (Ring + Innenfläche)
        const hole = `
          <circle class="kld-pin-hole-ring" cx="18" cy="14.3" r="6.6"></circle>
          <circle class="kld-pin-hole" cx="18" cy="14.3" r="5.2"></circle>
        `;

        const core = (state === 'red') ? redCore : hole;
        const numClass = (state === 'red') ? 'kld-pin-num dark' : 'kld-pin-num light';

        const html = `
          <div class="kld-pin2 ${state}">
            <svg viewBox="0 0 36 48" aria-hidden="true" focusable="false">
              <ellipse class="kld-shadow" cx="18" cy="45" rx="7.5" ry="2.2"></ellipse>
              <path class="kld-pin-shape"
                d="M18 2
                   C11.37 2 6 7.37 6 14
                   c0 9.1 12 23.5 12 23.5S30 23.1 30 14
                   C30 7.37 24.63 2 18 2z"></path>
              ${core}
              ${num ? `<text class="${numClass}" x="18" y="17.6" text-anchor="middle" font-size="${fs}">${num}</text>` : ``}
            </svg>
          </div>
        `;

        return L.divIcon({
          html,
          className: 'kld-pin2-icon',
          iconSize: [36, 48],
          iconAnchor: [18, 46],
        });
      }

      // Icons neu setzen: Nummerierung + aktuelles Objekt (grün)
      function refreshIcons() {
        window.allPoints.forEach(p => {
          const idx   = window.selected.indexOf(p.id);
          const isCur = (window.kldCurrentId && p.id === window.kldCurrentId);
          window.markerMap[p.id]?.setIcon(icon(idx >= 0 ? idx : null, isCur));
        });
      }

      // Von außen nutzbar (Suche/Objekt)
      window.kldSetCurrentId = function (id) {
        window.kldCurrentId = String(id || '');
        refreshIcons();
      };
      window.kldRefreshIcons = refreshIcons;

      // -------------------------------------------------------------------
      // Preview: Custom Punkt (eigener Marker)
      // -------------------------------------------------------------------
      function showCustomPreview(p) {
        activeId = p.id;
        const box = document.getElementById('kuladig-preview');

        box.innerHTML = `
          <h3>Eigener Punkt</h3>
          <p>Breitengrad: ${p.lat.toFixed(5)}<br>Längengrad: ${p.lng.toFixed(5)}</p>

          <button class="kld-pill-btn kld-pill-sm ${window.selected.includes(p.id) ? 'kld-pill-red' : 'kld-pill-green'}"
                  type="button" onclick="toggleRoute()">
            <span class="kld-pill-left" aria-hidden="true">${window.selected.includes(p.id) ? '➖' : '➕'}</span>
            <span class="kld-pill-right">
              <span class="kld-pill-text">${window.selected.includes(p.id) ? 'Aus Route entfernen' : 'Zur Route hinzufügen'}</span>
              <span class="kld-pill-emoji" aria-hidden="true">${window.selected.includes(p.id) ? '⛔' : '✅'}</span>
            </span>
          </button>
        `;
      }

      // -------------------------------------------------------------------
      // Preview: Objekt via AJAX laden
      // -------------------------------------------------------------------
      function loadObjectPreview(id) {
        activeId = id;
        const box = document.getElementById('kuladig-preview');
        box.innerHTML = '<p>Lade Objekt…</p>';

        fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=kuladig_objekt_preview&id=' + id)
          .then(r => r.json())
          .then(d => {
            if (!d) {
              box.innerHTML = '<p>Objekt konnte nicht geladen werden.</p>';
              return;
            }

            box.innerHTML = `
              ${d.img ? `<img src="${d.img}" loading="lazy">` : ``}
              <h3>${d.title}</h3>
              ${d.text}

              <div class="kld-pill-group" style="margin-top:.75rem;">
                <a class="kld-pill-btn kld-pill-sm kld-pill-blue" href="${d.url}">
                  <span class="kld-pill-left" aria-hidden="true">📄</span>
                  <span class="kld-pill-right">
                    <span class="kld-pill-text">Zur Objektseite</span>
                    <span class="kld-pill-emoji" aria-hidden="true">↗️</span>
                  </span>
                </a>

                <button class="kld-pill-btn kld-pill-sm ${window.selected.includes(id) ? 'kld-pill-red' : 'kld-pill-green'}"
                        type="button" onclick="toggleRoute()">
                  <span class="kld-pill-left" aria-hidden="true">${window.selected.includes(id) ? '➖' : '➕'}</span>
                  <span class="kld-pill-right">
                    <span class="kld-pill-text">${window.selected.includes(id) ? 'Aus Route entfernen' : 'Zur Route hinzufügen'}</span>
                    <span class="kld-pill-emoji" aria-hidden="true">${window.selected.includes(id) ? '⛔' : '✅'}</span>
                  </span>
                </button>
              </div>
            `;
          });
      }

      // -------------------------------------------------------------------
      // Route: Punkt hinzufügen/entfernen (Preview aktualisieren)
      // -------------------------------------------------------------------
      window.toggleRoute = function () {
        if (!activeId) return;

        if (window.selected.includes(activeId)) {
          window.selected = window.selected.filter(x => x !== activeId);
        } else {
          window.selected.push(activeId);
        }

        save();
        refreshIcons();

        const p = window.allPoints.find(x => x.id === activeId);
        if (p?.type === 'custom') showCustomPreview(p);
        else loadObjectPreview(activeId);
      };

      // -------------------------------------------------------------------
      // Route: Google Maps öffnen (mind. 2 Punkte)
      // -------------------------------------------------------------------
      window.openRoute = function () {
        if (selected.length < 2) {
          alert('Mindestens zwei Punkte auswählen.');
          return;
        }

        const path = selected.map(id => {
          const p = allPoints.find(x => x.id === id);
          return `${p.lat},${p.lng}`;
        }).join('/');

        window.open('https://www.google.com/maps/dir/' + path, '_blank');
      };

      // -------------------------------------------------------------------
      // Marker bauen (Objekte + evtl. Custom aus Storage)
      // -------------------------------------------------------------------
      allPoints.forEach(p => {
        const m = L.marker([p.lat, p.lng], { icon: icon() }).addTo(window.kuladigMap);
        markerMap[p.id] = m;

        m.on('click', () => {
          if (p.type === 'custom') showCustomPreview(p);
          else loadObjectPreview(p.id);
        });
      });

      // Klick auf Karte: Custom Marker hinzufügen
      window.kuladigMap.on('click', e => {
        const id = 'custom-' + Date.now();
        const point = { id, type: 'custom', lat: e.latlng.lat, lng: e.latlng.lng };
        allPoints.push(point);

        const m = L.marker([point.lat, point.lng], { icon: icon() }).addTo(window.kuladigMap);
        markerMap[id] = m;
        m.on('click', () => showCustomPreview(point));

        save();
        showCustomPreview(point);
      });

      // Initial: Icons korrekt setzen (Route-Nummern etc.)
      refreshIcons();

      // Debug/extern: Marker + Punkte verfügbar machen
      window.kuladigMarkers = markerMap;
      window.kuladigPoints  = allPoints;

      /* =========================
         ROUTE LÖSCHEN
      ========================= */
      window.clearRoute = function () {
        window.selected = [];
        localStorage.removeItem(STORAGE_KEY);
        refreshIcons();

        const box = document.getElementById('kuladig-preview');
        if (box) {
          box.innerHTML = '<p>Route wurde gelöscht.</p>';
        }
      };

      /* =========================
         EIGENE MARKER ENTFERNEN
      ========================= */
      window.removeCustomMarkers = function () {

        // Alle Custom-Points finden
        const customIds = window.allPoints
          .filter(p => p.type === 'custom')
          .map(p => p.id);

        // Marker von der Karte entfernen
        customIds.forEach(id => {
          if (window.markerMap[id]) {
            window.kuladigMap.removeLayer(window.markerMap[id]);
            delete window.markerMap[id];
          }
        });

        // Aus allPoints & selected entfernen
        window.allPoints = window.allPoints.filter(p => p.type !== 'custom');
        window.selected  = window.selected.filter(id => !customIds.includes(id));

        // Speicher aktualisieren
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          selected: window.selected,
          custom: []
        }));

        refreshIcons();

        const box = document.getElementById('kuladig-preview');
        if (box) {
          box.innerHTML = '<p>Eigene Marker wurden entfernt.</p>';
        }
      };

      /* =========================
         FOCUS CURRENT OBJECT
      ========================= */
      window.focusCurrentObject = function () {
        const currentId = '<?php echo esc_js($_GET["kuladig_id"] ?? ""); ?>';
        if (!currentId) {
          console.warn('Keine kuladig_id in URL');
          return;
        }

        const marker = window.kuladigMarkers?.[currentId];
        const point  = window.kuladigPoints?.find(p => p.id === currentId);

        if (!marker || !point) {
          console.warn('Objekt-Marker nicht gefunden:', currentId);
          return;
        }

        window.kuladigMap.setView([point.lat, point.lng], 15, { animate: true });

        // Current-ID setzen -> grün highlighten (über refreshIcons)
        window.kldCurrentId = currentId;
        refreshIcons();

        // "current"-Klasse entfernen/setzen
        Object.values(window.kuladigMarkers).forEach(m => {
          const el = m.getElement()?.querySelector('.kuladig-marker');
          if (el) el.classList.remove('current');
        });

        const el = marker.getElement()?.querySelector('.kuladig-marker');
        if (el) el.classList.add('current');
      };

    })();
  </script>

  <?php
  return ob_get_clean(); // Shortcode-HTML zurückgeben (Buffer holen + leeren)
});

/* =====================================================================
   AJAX: Objekt-Preview (Sidebar lädt Details per admin-ajax.php)
====================================================================== */
add_action('wp_ajax_kuladig_objekt_preview', 'kuladig_objekt_preview');
add_action('wp_ajax_nopriv_kuladig_objekt_preview', 'kuladig_objekt_preview');

/* AJAX-Handler: liefert JSON (Titel, Thumbnail, Text, Link) */
function kuladig_objekt_preview() {
  $id = sanitize_text_field($_GET['id'] ?? '');
  if (!$id) wp_send_json(null);

  $data = kuladig_api_get('Objekt/' . $id);
  if (!$data) wp_send_json(null);

  // Thumbnail (wenn vorhanden)
  $img = '';
  if (!empty($data['Dokumente'][0]['Thumbnail3Token'])) {
    $img = 'https://www.kuladig.de/api/public/Dokument?token=' . $data['Dokumente'][0]['Thumbnail3Token'];
  }

  wp_send_json([
    'id'    => $id,
    'title' => $data['Name'] ?? '',
    'img'   => $img,

    // Beschreibung: BBCode -> HTML -> Tags strippen -> kürzen -> als <p> zurückgeben
    'text'  => wpautop(
      wp_trim_words(
        wp_strip_all_tags(
          kuladig_parse_bbcode($data['Beschreibung'] ?? '')
        ),
        60,
        ' …'
      )
    ),

    'url'   => home_url('/objektansicht/?kuladig_id=' . $id),
  ]);
}
