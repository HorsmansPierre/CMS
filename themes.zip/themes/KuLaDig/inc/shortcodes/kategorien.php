<?php
/**
 * Shortcode: [kuladig_kategorien]
 * - Baut ein Kategorien-Grid aus den neuesten KuLaDig-Objekten
 * - Nutzt Transients als Cache
 * - Im Backend/Editor: statische Vorschau (damit Elementor nicht „leer“ wirkt)
 */

add_shortcode('kuladig_kategorien', function () {


  /* =====================================================================
     Cache (Transient): fertiges HTML für schnellere Auslieferung
  ====================================================================== */
  $cache_key = 'cms_kld_cat_grid_boxed_v53';
  $cached = get_transient($cache_key);
  if ($cached !== false) return $cached;

  /* =====================================================================
     API-Helfer (nutzt kuladig_api_get, falls vorhanden; sonst Fallback)
  ====================================================================== */
  $api_get = function ($path, $args = [], $ttl = 180) {
    // Wenn der globale API-Client existiert: den nutzen
    if (function_exists('kuladig_api_get')) return kuladig_api_get($path, $args, $ttl);

    // Fallback (falls kuladig_api_get mal nicht geladen ist)
    $base = 'https://www.kuladig.de/api/public/';
    $url  = add_query_arg($args, trailingslashit($base) . ltrim($path, '/'));
    $resp = wp_remote_get($url, ['timeout' => 12]);
    if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) return null;

    $data = json_decode(wp_remote_retrieve_body($resp), true);
    return is_array($data) ? $data : null;
  };

  /* =====================================================================
     Bild-Ermittlung: ThumbnailToken → sonst Detailcall → erstes Dokument
  ====================================================================== */
  $first_image = function ($row) use ($api_get) {
    if (!empty($row['ThumbnailToken'])) {
      return 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($row['ThumbnailToken']);
    }

    if (!empty($row['Id'])) {
      $detail = $api_get('Objekt/' . $row['Id'], [], 12 * HOUR_IN_SECONDS);

      if (!empty($detail['Dokumente']) && is_array($detail['Dokumente'])) {
        foreach ($detail['Dokumente'] as $d) {
          if (!empty($d['Token'])) {
            return 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($d['Token']);
          }
        }
      }
    }

    return '';
  };

  /* =====================================================================
     Label-Extraktion: Themen/Schlagwörter/Kategorien aus Detail
  ====================================================================== */
  $extract_labels = function ($detail) {
    $labels = [];

    foreach (['Themen', 'Thema', 'Schlagwoerter', 'Schlagworte', 'Kategorien', 'Kategorie'] as $key) {
      if (empty($detail[$key])) continue;

      $vals = is_array($detail[$key]) ? $detail[$key] : [$detail[$key]];

      foreach ($vals as $v) {
        $t = trim(strip_tags((string) $v));
        if ($t !== '') $labels[] = $t;
      }
    }

    return array_values(array_unique($labels));
  };

  /* =====================================================================
     Konfiguration / Sammler
  ====================================================================== */
  $maxCatsTotal = 30; // maximal so viele Cards insgesamt sammeln
  $maxVisible   = 8;  // initial sichtbar, wenn Suchfeld leer ist

  $catCards   = [];  // Ergebnis: [label => cardData]
  $usedLabels = [];  // Dedupe: Label nur einmal
  $usedObjIds = [];  // Dedupe: Objekt-ID nur einmal

  /* =====================================================================
     Datenquelle: gleiche Master-Liste wie Karte/Startseite
  ====================================================================== */
  $rows = kuladig_site_objects(3 * HOUR_IN_SECONDS); // gleiche 200 wie Karte/Startseite/Suche, ...

  if (!empty($rows)) {
    foreach ($rows as $row) {

      if (count($catCards) >= $maxCatsTotal) break;

      $objId = $row['Id'] ?? '';
      if (!$objId) continue;

      // Detail laden (für Labels & Schlagwörter)
      $detail = $api_get('Objekt/' . $objId, [], 12 * HOUR_IN_SECONDS);

      $labels = $extract_labels($detail);
      $img    = $first_image($row);

      if (!$img || empty($labels)) continue;

      // Pro Objekt nur eine Kategorie-Card erzeugen
      foreach ($labels as $label) {
        $norm = mb_strtolower(trim($label));

        if (isset($usedLabels[$norm])) continue;
        if (isset($usedObjIds[$objId])) continue;

        // Schlagwörter -> tags für Client-Suche (einfaches Matching)
        $schlagwoerter = array_map(
          fn($s) => is_array($s) ? ($s[1] ?? null) : $s,
          $detail['Schlagwoerter'] ?? []
        );

        $tags = implode(
          ' ',
          array_map(
            fn($t) => mb_strtolower(trim((string) $t)),
            array_filter($schlagwoerter)
          )
        );

        // Beschreibung (Detail bevorzugt, sonst Row) + grobe Bereinigung
        $rawDesc = (string) ($detail['Beschreibung'] ?? ($row['Beschreibung'] ?? ''));

        // BBCode / [tags] grob entfernen (damit kein Müll bleibt)
        $rawDesc = preg_replace('/\[[^\]]+\]/u', ' ', $rawDesc);

        // Entities dekodieren + nbsp raus + Whitespace glätten + Tags entfernen
        $desc = html_entity_decode($rawDesc, ENT_QUOTES, 'UTF-8');
        $desc = str_replace("\xC2\xA0", ' ', $desc);
        $desc = preg_replace('/\s+/u', ' ', $desc);
        $desc = trim(wp_strip_all_tags($desc));

        // Card speichern
        $catCards[$label] = [
          'img'  => esc_url($img),
          'name' => esc_html($row['Name'] ?? ''),
          'desc' => $desc,
          'href' => home_url('/objektansicht/?kuladig_id=' . urlencode($row['Id'])),
          'tags' => $tags,
        ];

        // Markieren: Label & Objekt sind „verbraucht“
        $usedLabels[$norm] = true;
        $usedObjIds[$objId] = true;
        break;
      }
    }
  }

  ob_start(); ?>

  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- ===== KATEGORIEN-SECTION ===== -->
  <section id="kld-cat-section" class="py-5" lang="de">

    <div class="kld-cat-inner">

      <!-- überschrift -->
      <div class="section-header">
        <h3>Kategorien</h3>
        <p>Entdecke Empfehlungen zu Themen und Sammlungen aus KuLaDig</p>
      </div>

      <!-- Suchfeld -->
      <div class="mb-4">
        <input
          type="search"
          id="kld-cat-search"
          class="form-control"
          placeholder="Nach Kategorie suchen..."
        >
      </div>

      <?php if (empty($catCards)) : ?>

        <!-- Keine Ergebnisse -->
        <div class="alert alert-info mb-0">Keine Kategorien gefunden.</div>

      <?php else : ?>

        <!-- Grid -->
        <div class="row g-4" id="kld-cat-grid">
          <?php
          $index = 0;

          foreach ($catCards as $catName => $first) :
            // Initial nur die ersten 8 zeigen (wenn Suchfeld leer ist)
            $visible = ($index < $maxVisible) ? '' : 'display:none;';
            $index++;
          ?>
            <div
              class="col-12 col-md-6 col-lg-3 kld-cat-item"
              data-name="<?php echo esc_attr(mb_strtolower($first['name'])); ?>"
              data-tags="<?php echo esc_attr($first['tags']); ?>"
              style="<?php echo $visible; ?>"
            >
              <article class="card">

                <?php if (!empty($first['img'])) : ?>
                  <img
                    class="card-img-top"
                    src="<?php echo esc_url($first['img']); ?>"
                    alt="<?php echo esc_attr($catName); ?>"
                    loading="lazy"
                  >
                <?php endif; ?>

                <div class="card-body">
                  <h4 class="h6 mb-1"><?php echo esc_html($first['name']); ?></h4>

                  <!-- Trefferanzeige (wird per JS eingeblendet, wenn Match über tags) -->
                  <small class="kld-hit" style="display:none;color:#64748b;"></small>

                  <p class="small mb-0 kld-card-desc" lang="de">
                    <?php echo esc_html(wp_trim_words($first['desc'], 220, ' …')); ?>
                  </p>

                  <?php if (!empty($first['href'])) : ?>
                    <a class="stretched-link" href="<?php echo esc_url($first['href']); ?>"></a>
                  <?php endif; ?>
                </div>

              </article>
            </div>
          <?php endforeach; ?>
        </div>

      <?php endif; ?>

    </div>
  </section>

  <!-- =====================================================================
       JavaScript:
       - Filtert Cards anhand Suchbegriff
       - Wenn Suchfeld leer: zeigt nur die ersten 8 Cards
       - Trefferlogik: Name hat Vorrang, sonst Schlagwort (tags)
  ====================================================================== -->
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const input = document.querySelector('#kld-cat-search');
      const cards = document.querySelectorAll('.kld-cat-item');
      if (!input || !cards.length) return;

      input.addEventListener('input', function () {
        const q = this.value.trim().toLowerCase();

        // Reset: Suchfeld leer -> nur erste 8 anzeigen, Trefferlabel ausblenden
        if (!q) {
          cards.forEach((card, i) => {
            card.style.display = i < 8 ? '' : 'none';

            const hit = card.querySelector('.kld-hit');
            if (hit) hit.style.display = 'none';
          });
          return;
        }

        // Filter aktiv: alles matchen (Name zuerst, sonst tags)
        cards.forEach((card) => {
          const name = card.dataset.name || '';
          const tagsArr = (card.dataset.tags || '').split(' ');
          let hitWord = null;

          // 1) Name hat Vorrang
          if (name.includes(q)) {
            hitWord = null;
          }
          // 2) Sonst Schlagwort prüfen
          else {
            hitWord = tagsArr.find(t => t.includes(q)) || null;
          }

          const match = name.includes(q) || hitWord !== null;
          card.style.display = match ? '' : 'none';

          // Trefferlabel nur anzeigen, wenn Match über tags (nicht über Name)
          const hit = card.querySelector('.kld-hit');
          if (hit) {
            if (hitWord) {
              hit.textContent = 'Treffer: ' + hitWord;
              hit.style.display = 'block';
            } else {
              hit.style.display = 'none';
            }
          }
        });
      });
    });
  </script>

  <?php
  $html = ob_get_clean();

  // Cache für 30 Minuten speichern (HTML komplett)
  set_transient($cache_key, $html, 30 * MINUTE_IN_SECONDS);

  return $html;
});
