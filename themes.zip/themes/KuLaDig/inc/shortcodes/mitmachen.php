<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_mitmachen]
 *
 * Speichert Formular-Einsendungen als JSONL (JSON pro Zeile) in:
 *   uploads/kuladig-hinweise/hinweise.jsonl
 * (Später könnte man das im Admin-Panel einlesen und anzeigen.)
 */

/* =====================================================================
   Storage helpers (Dateipfade + Schreiben ins JSONL-File)
====================================================================== */

if (!function_exists('kuladig_hint_storage_dir')) {
  // Basis-Ordner: wp-content/uploads/kuladig-hinweise
  function kuladig_hint_storage_dir(): string {
    $u = wp_upload_dir();
    return trailingslashit($u['basedir']) . 'kuladig-hinweise';
  }
}

if (!function_exists('kuladig_hint_storage_file')) {
  // JSONL-Datei: wp-content/uploads/kuladig-hinweise/hinweise.jsonl
  function kuladig_hint_storage_file(): string {
    return trailingslashit(kuladig_hint_storage_dir()) . 'hinweise.jsonl';
  }
}

if (!function_exists('kuladig_hint_ensure_dirs')) {
  // Stellt sicher, dass der Hinweis-Ordner + attachments-Unterordner existieren
  function kuladig_hint_ensure_dirs(): bool {
    $base = kuladig_hint_storage_dir();
    $att  = trailingslashit($base) . 'attachments';

    if (!file_exists($base)) {
      if (!wp_mkdir_p($base)) return false;
    }
    if (!file_exists($att)) {
      if (!wp_mkdir_p($att)) return false;
    }
    return true;
  }
}

if (!function_exists('kuladig_hint_append_jsonl')) {
  // Hängt 1 JSON-Datensatz als "eine Zeile" an die JSONL-Datei an
  function kuladig_hint_append_jsonl(array $record): bool {
    if (!kuladig_hint_ensure_dirs()) return false;

    $file = kuladig_hint_storage_file();
    $line = wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";

    $fh = @fopen($file, 'ab');
    if (!$fh) return false;

    // Sperrt Datei kurz exklusiv, damit nichts "ineinander" schreibt
    if (function_exists('flock')) @flock($fh, LOCK_EX);
    $ok = (@fwrite($fh, $line) !== false);
    if (function_exists('flock')) @flock($fh, LOCK_UN);
    @fclose($fh);

    return $ok;
  }
}

/* =====================================================================
   Abuse protection (Rate-Limit pro IP)
====================================================================== */

if (!function_exists('kuladig_hint_rate_limit_ok')) {
  // Simple Rate-Limit: max. $limit Submits pro IP im Zeitfenster $windowSeconds
  function kuladig_hint_rate_limit_ok(string $ip, int $limit = 8, int $windowSeconds = 3600): bool {
    $key = 'kld_hint_rl_' . md5($ip);
    $data = get_transient($key);
    if (!is_array($data)) $data = ['n' => 0];

    if ((int)$data['n'] >= $limit) return false;

    $data['n'] = (int)$data['n'] + 1;
    set_transient($key, $data, $windowSeconds);
    return true;
  }
}

/* =====================================================================
   Captcha (Mathe-Aufgabe + Token in Transient)
====================================================================== */

if (!function_exists('kuladig_hint_make_captcha')) {
  // Erzeugt eine Mathe-Aufgabe und speichert die Lösung serverseitig (Transient) unter Token
  function kuladig_hint_make_captcha(int $ttl = 30 * MINUTE_IN_SECONDS): array {
    $a = random_int(2, 12);
    $b = random_int(2, 12);
    $op = random_int(0, 1) ? '+' : '−';

    $answer = ($op === '+') ? ($a + $b) : ($a - $b);

    // Keine negativen Ergebnisse (damit es für Nutzer "einfach" bleibt)
    if ($op === '−' && $answer < 0) {
      $op = '+';
      $answer = $a + $b;
    }

    $token = wp_generate_password(20, false, false);
    set_transient('kld_captcha_' . $token, (string)$answer, $ttl);

    return [
      'token' => $token,
      'label' => "{$a} {$op} {$b} = ?",
    ];
  }
}

if (!function_exists('kuladig_hint_ajax_captcha')) {
  // AJAX-Endpoint: liefert neue Captcha-Aufgabe (label + token) als JSON
  add_action('wp_ajax_kuladig_hint_captcha', 'kuladig_hint_ajax_captcha');
  add_action('wp_ajax_nopriv_kuladig_hint_captcha', 'kuladig_hint_ajax_captcha');

  function kuladig_hint_ajax_captcha() {
    $c = kuladig_hint_make_captcha();
    wp_send_json_success($c);
  }
}

/* =====================================================================
   Attachments – speichert Uploads in uploads/kuladig-hinweise/attachments/
====================================================================== */

if (!function_exists('kuladig_hint_handle_uploads')) {
  function kuladig_hint_handle_uploads(string $field, int $maxFiles = 3): array {
    if (empty($_FILES[$field]) || !is_array($_FILES[$field]['name'])) return [];
    if (!kuladig_hint_ensure_dirs()) return [];

    // WP File helpers (hier v.a. wegen ABSPATH-Sicherheit / Standard-Setup)
    require_once ABSPATH . 'wp-admin/includes/file.php';

    // Whitelist erlaubter MIME-Types
    $allowed = [
      'image/jpeg',
      'image/png',
      'image/webp',
      'application/pdf',
    ];

    $u = wp_upload_dir();
    $baseDir = trailingslashit(kuladig_hint_storage_dir()) . 'attachments';
    $baseUrl = trailingslashit($u['baseurl']) . 'kuladig-hinweise/attachments';

    $names = $_FILES[$field]['name'];
    $count = min(count($names), $maxFiles);

    $out = [];

    for ($i = 0; $i < $count; $i++) {
      $origName = (string)($_FILES[$field]['name'][$i] ?? '');
      if ($origName === '') continue;

      $err = (int)($_FILES[$field]['error'][$i] ?? UPLOAD_ERR_NO_FILE);
      if ($err !== UPLOAD_ERR_OK) continue;

      $type = (string)($_FILES[$field]['type'][$i] ?? '');
      $size = (int)($_FILES[$field]['size'][$i] ?? 0);

      // Limits: nur erlaubte Typen + max 5MB
      if (!in_array($type, $allowed, true)) continue;
      if ($size <= 0 || $size > 5 * 1024 * 1024) continue;

      $tmp = [
        'name'     => $origName,
        'type'     => $type,
        'tmp_name' => $_FILES[$field]['tmp_name'][$i] ?? '',
        'error'    => $err,
        'size'     => $size,
      ];

      // Ziel-Dateiname: eindeutig
      $unique = wp_unique_filename(
        $baseDir,
        'kldhint_' . preg_replace('/[^a-zA-Z0-9._-]+/', '_', $origName)
      );

      $destPath = trailingslashit($baseDir) . $unique;

      // Manuell verschieben (mehr Kontrolle als wp_handle_upload)
      $moved = @move_uploaded_file($tmp['tmp_name'], $destPath);
      if (!$moved) continue;

      @chmod($destPath, 0644);

      $out[] = [
        'original_name' => sanitize_text_field($origName),
        'mime'          => sanitize_text_field($type),
        'size'          => $size,
        'path'          => $destPath,
        'url'           => trailingslashit($baseUrl) . rawurlencode(basename($destPath)),
      ];
    }

    return $out;
  }
}

/* =====================================================================
   Submit handler – verarbeitet POST und schreibt JSONL
====================================================================== */

if (!function_exists('kuladig_hint_submit')) {
  add_action('admin_post_kuladig_hint_submit', 'kuladig_hint_submit');
  add_action('admin_post_nopriv_kuladig_hint_submit', 'kuladig_hint_submit');

  function kuladig_hint_submit() {

    // Zurück zur Seite, von der das Formular kam (oder fallback /mitmachen)
    $ref = wp_get_referer() ?: home_url('/mitmachen');

    /* -----------------------
       Security: Nonce
    ------------------------ */
    $nonce = $_POST['kuladig_hint_nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'kuladig_hint')) {
      wp_safe_redirect(add_query_arg('kld_sent', '0', $ref));
      exit;
    }

    /* -----------------------
       Security: Honeypot
    ------------------------ */
    if (!empty($_POST['website'])) {
      // Bots füllen das oft aus -> wir tun so, als wäre es ok (Bots nicht "trainieren")
      wp_safe_redirect(add_query_arg('kld_sent', '1', $ref));
      exit;
    }

    /* -----------------------
       Security: Rate-Limit
    ------------------------ */
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (!kuladig_hint_rate_limit_ok($ip)) {
      wp_safe_redirect(add_query_arg('kld_sent', 'rate', $ref));
      exit;
    }

    /* -----------------------
       Security: Captcha
    ------------------------ */
    $capToken = sanitize_text_field($_POST['captcha_token'] ?? '');
    $capUser  = sanitize_text_field($_POST['captcha_answer'] ?? '');

    $capRight = get_transient('kld_captcha_' . $capToken);
    delete_transient('kld_captcha_' . $capToken); // single-use (nach Versuch löschen)

    if ($capRight === null || $capUser === '' || trim($capUser) !== trim((string)$capRight)) {
      wp_safe_redirect(add_query_arg('kld_sent', 'captcha', $ref));
      exit;
    }

    /* -----------------------
       Fields: Sanitizing
    ------------------------ */
    $subject = sanitize_text_field($_POST['subject'] ?? 'KuLaDig: Hinweis');
    $from    = sanitize_text_field($_POST['from'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');

    $msgRaw  = trim((string)($_POST['message'] ?? ''));
    $msgSafe = trim(wp_strip_all_tags(wp_kses_post($msgRaw)));

    if ($msgSafe === '') {
      wp_safe_redirect(add_query_arg('kld_sent', 'empty', $ref));
      exit;
    }

    /* -----------------------
       Attachments (optional)
    ------------------------ */
    $attachments = kuladig_hint_handle_uploads('attachments', 3);

    /* -----------------------
       JSONL Record (eine Zeile)
    ------------------------ */
    $record = [
      'id'          => wp_generate_uuid4(),
      'created_at'  => gmdate('c'),
      'subject'     => $subject,
      'from'        => $from,
      'email'       => $email,
      'message'     => $msgSafe,
      'attachments' => $attachments,
      'meta' => [
        'ip'         => $ip,
        'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
        'referrer'   => esc_url_raw($ref),
      ],
    ];

    // Schreiben & Ergebnis zurück zur Seite
    $ok = kuladig_hint_append_jsonl($record);

    wp_safe_redirect(add_query_arg('kld_sent', $ok ? '1' : '0', $ref));
    exit;
  }
}

/* =====================================================================
   Shortcode UI (Formular + Captcha-Refresh per AJAX)
====================================================================== */

add_shortcode('kuladig_mitmachen', function () {

  $sent = sanitize_text_field($_GET['kld_sent'] ?? '');
  $captcha = kuladig_hint_make_captcha();

  ob_start(); ?>

  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <section id="kld-mitmachen" class="my-4 my-lg-5">

    <div class="container">
      <div class="row g-4 align-items-stretch">

        <!-- Info-Seite links -->
        <div class="col-12 col-lg-5">
          <div class="kld-side">
            <h2 class="h3 mb-2">Mitmachen / Hinweis geben</h2>
            <p class="mb-3">
              Sie können mitmachen, indem Sie
            </p>
            <ul class="mb-3">
              <li>uns Hinweise zu bestehenden Objekteinträgen geben</li>
              <li>uns auf potenzielle neue KuLaDig-Objekte hinweisen, die noch nicht im System sind</li>
              <li>Inhalte beisteuern oder z.B. historische/eigene Fotos schicken</li>
            </ul>
            <p class="mb-0">
              Die Hinweise werden intern gespeichert und von Admins geprüft.
            </p>
          </div>
        </div>

        <!-- Formular rechts -->
        <div class="col-12 col-lg-7">
          <div class="kld-shell">

            <!-- Statusmeldungen per URL-Parameter kld_sent -->
            <?php if ($sent === '1') : ?>
              <div class="alert alert-success mb-3">Danke! Dein Hinweis wurde gespeichert.</div>
            <?php elseif ($sent === 'captcha') : ?>
              <div class="alert alert-warning mb-3">Sicherheitsabfrage war leider falsch. Bitte nochmal.</div>
            <?php elseif ($sent === 'rate') : ?>
              <div class="alert alert-warning mb-3">Zu viele Versuche. Bitte in einer Stunde nochmal probieren.</div>
            <?php elseif ($sent === 'empty') : ?>
              <div class="alert alert-warning mb-3">Bitte eine Nachricht eingeben.</div>
            <?php elseif ($sent === '0') : ?>
              <div class="alert alert-danger mb-3">Speichern hat nicht geklappt. Bitte später erneut versuchen.</div>
            <?php endif; ?>

            <!-- Formular: sendet an admin-post.php (WP Standard) -->
            <form
              method="post"
              action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
              enctype="multipart/form-data"
              class="row g-3"
            >

              <!-- Routing: welcher Handler soll laufen -->
              <input type="hidden" name="action" value="kuladig_hint_submit">

              <?php wp_nonce_field('kuladig_hint', 'kuladig_hint_nonce'); ?>

              <!-- Honeypot (Bots): soll leer bleiben -->
              <div class="kld-hp" aria-hidden="true">
                <label>Website</label>
                <input type="text" name="website" tabindex="-1" autocomplete="off">
              </div>

              <div class="col-12">
                <label class="form-label fw-semibold">Betreff</label>
                <input name="subject" class="form-control" value="KuLaDig: Hinweis" required>
              </div>

              <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">Hinweisgeber</label>
                <input name="from" class="form-control" placeholder="Name (optional)">
              </div>

              <div class="col-12 col-md-6">
                <label class="form-label fw-semibold">E-Mail</label>
                <input name="email" type="email" class="form-control" placeholder="E-Mail (optional)">
              </div>

              <div class="col-12">
                <label class="form-label fw-semibold">Nachricht</label>
                <textarea name="message" class="form-control" rows="6" required></textarea>
                <div class="form-text">
                  Deine Angaben werden nur zur Bearbeitung des Hinweises verwendet (DSGVO).
                </div>
              </div>

              <div class="col-12">
                <label class="form-label fw-semibold">Anhang (optional)</label>
                <input
                  type="file"
                  name="attachments[]"
                  class="form-control"
                  multiple
                  accept=".jpg,.jpeg,.png,.webp,.pdf"
                >
                <div class="form-text">
                  Max. 3 Dateien, je 5 MB (JPG/PNG/WEBP/PDF). Dateien werden serverseitig gespeichert.
                </div>
              </div>

              <!-- Captcha: Label + Refresh + Token + Eingabe -->
              <div class="col-12">
                <label class="form-label fw-semibold">Sicherheitsabfrage</label>
                <div class="kld-captcha">
                  <span id="kld-cap-label" class="badge"><?php echo esc_html($captcha['label']); ?></span>

                  <button
                    type="button"
                    id="kld-cap-refresh"
                    class="btn btn-outline-secondary btn-sm"
                    aria-label="Neue Aufgabe"
                  >
                    ↻
                  </button>

                  <input
                    type="hidden"
                    name="captcha_token"
                    id="kld-cap-token"
                    value="<?php echo esc_attr($captcha['token']); ?>"
                  >

                  <input
                    name="captcha_answer"
                    class="form-control"
                    style="max-width:180px"
                    placeholder="Ergebnis"
                    required
                  >
                </div>
              </div>

              <!-- Aktionen -->
              <div class="col-12 kld-actions-row">
                <a class="kld-pill-btn kld-pill-sm kld-pill-red" href="<?php echo esc_url(home_url('/')); ?>">
                  <span class="kld-pill-left" aria-hidden="true">↩️</span>
                  <span class="kld-pill-right">
                    <span class="kld-pill-text">Abbrechen</span>
                    <span class="kld-pill-emoji" aria-hidden="true">✖️</span>
                  </span>
                </a>

                <button class="kld-pill-btn kld-pill-sm kld-pill-green" type="submit">
                  <span class="kld-pill-left" aria-hidden="true">📨</span>
                  <span class="kld-pill-right">
                    <span class="kld-pill-text">Absenden</span>
                    <span class="kld-pill-emoji" aria-hidden="true">✅</span>
                  </span>
                </button>
              </div>

            </form>

          </div>
        </div>
      </div>
    </div>

    <!-- =====================================================================
         JavaScript:
    ====================================================================== -->

    <script>
      document.addEventListener('DOMContentLoaded', function () {
        const btn   = document.getElementById('kld-cap-refresh');
        const label = document.getElementById('kld-cap-label');
        const token = document.getElementById('kld-cap-token');

        if (!btn || !label || !token) return;

        // Klick: neue Captcha-Aufgabe via WP-AJAX holen
        btn.addEventListener('click', async function () {
          try {
            const url = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>?action=kuladig_hint_captcha";
            const res = await fetch(url, { credentials: 'same-origin', cache: 'no-store' });
            const j = await res.json();

            // Antwort: label + token austauschen
            if (j && j.success && j.data) {
              label.textContent = j.data.label;
              token.value = j.data.token;
            }
          } catch (e) {}
        });
      });
    </script>

  </section>

  <?php
  return ob_get_clean();
});
