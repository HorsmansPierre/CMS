<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_impressum title="Impressum"]
 * - Schickes Impressum im KuLaDig-Design
 */
add_shortcode('kuladig_impressum', function ($atts) {

  // Shortcode-Attribute
  $a = shortcode_atts([
    'title' => 'Impressum',
  ], $atts);

  // Titel aus Attributen (sauber als String)
  $title = trim((string)$a['title']);

  // =====================================================================
  // PHP: Betreiber/Verantwortliche Daten
  // =====================================================================
  $proto = [
    'name'  => 'Universitätsprojekt / Kuladig',
    'org'   => 'Hochschule Kaiserslautern Standort Zweibrücken',
    'addr'  => 'Amerikastraße 1, 66482 Zweibrücken',
    'email' => 'piho1002@stud.hs-kl.de',
    'phone' => '+352 621 311 275',
    'resp'  => 'Verantwortliche Person nach § 18 Abs. 2 MStV (Horsmans Pierre)',
  ];

  // Offizielle Quelle / Referenz (externer Link)
  $official_impressum_url = 'https://www.kuladig.de/Impressum';

  ob_start(); ?> <!-- Output-Buffering: HTML sammeln und am Ende als Shortcode-String zurückgeben -->

  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- Seiten-Wrapper (Impressum) -->
  <section class="kld-imp-wrap">

    <!-- Optionaler Titel aus Shortcode-Attribut -->
    <?php if ($title !== ''): ?>
      <h2 class="kld-imp-title"><?php echo esc_html($title); ?></h2>
    <?php endif; ?>

    <!-- Einleitung / Kontext -->
    <p class="kld-imp-lead">
      Dieses Webangebot ist ein <strong>Prototyp</strong> und wird auf einem Universitätsserver betrieben.
      Inhalte (Objekte, Metadaten, Vorschaubilder) werden – soweit verfügbar – über öffentliche Schnittstellen (API) aus KuLaDig geladen.
    </p>

    <!-- Callout: rechtlicher Hinweis / Einordnung -->
    <div class="kld-callout">
      <h3>Wichtiger Hinweis</h3>
      <p style="margin:0; line-height:1.55;">
        Die dargestellten Informationen dienen der allgemeinen Orientierung und sind <strong>nicht rechtsverbindlich</strong>.
        Für verbindliche Auskünfte und vollständige Nachweise sind ggf. amtliche Quellen bzw. zuständige Fachbehörden heranzuziehen.
      </p>
    </div>

    <!-- Zweispaltiges Layout (Desktop) -->
    <div class="kld-grid">

      <!-- =======================
           BOX: Betreiber
      ======================== -->
      <div class="kld-box">
        <h3>Betreiber dieses Prototyps</h3>

        <!-- Key/Value-Liste (Definition List) -->
        <dl class="kld-kv">
          <dt>Anbieter</dt>
          <dd><?php echo esc_html($proto['name']); ?></dd>

          <dt>Organisation</dt>
          <dd><?php echo esc_html($proto['org']); ?></dd>

          <dt>Anschrift</dt>
          <dd><?php echo esc_html($proto['addr']); ?></dd>

          <dt>Kontakt</dt>
          <dd>
            <?php echo esc_html($proto['email']); ?>
            <?php if (!empty($proto['phone'])): ?><br><?php echo esc_html($proto['phone']); ?><?php endif; ?>
          </dd>

          <dt>Verantwortlich i.S.d. § 18 Abs. 2 MStV</dt>
          <dd><?php echo esc_html($proto['resp']); ?></dd>
        </dl>

        <hr class="kld-hr">

        <!-- Zusatzhinweis zum Prototyp -->
        <p class="kld-small">
          Hinweis: Es gibt in diesem Prototyp <strong>keine echten Benutzerkonten</strong> und keine verbindlichen Login-Funktionen.
          Formulare (z.B. „Mitmachen“) dienen der Erfassung von Hinweisen und werden intern gespeichert, nicht automatisch per E-Mail versendet.
        </p>
      </div>

      <!-- =======================
           BOX: Datenquelle / Rechte
      ======================== -->
      <div class="kld-box">
        <h3>Datenquelle & Rechtehinweis</h3>

        <p class="kld-muted" style="margin:0;">
          Dieses Projekt nutzt Inhalte aus <strong>KuLaDig (Kultur. Landschaft. Digital.)</strong>.
          KuLaDig ist ein eigenständiges Angebot; dieses Prototyp-Projekt ist <strong>nicht</strong> das offizielle KuLaDig-Portal.
        </p>

        <ul class="kld-list">
          <li>
            Offizielles KuLaDig-Impressum:
            <a class="kld-link" href="<?php echo esc_url($official_impressum_url); ?>" target="_blank" rel="noopener">
              <?php echo esc_html($official_impressum_url); ?>
            </a>
          </li>
          <li>
            Urheber-/Nutzungsrechte an Texten, Logos, Bildern und Daten liegen grundsätzlich bei den jeweiligen Rechteinhabern bzw. beim offiziellen Angebot.
          </li>
          <li>
            Wenn Inhalte fehlen, fehlerhaft wirken oder nicht vollständig sind, kann das an der Datenquelle oder an der technischen Aufbereitung im Prototyp liegen.
          </li>
        </ul>
      </div>

    </div>

    <!-- =======================
         BOX: Haftung / Links / Urheberrecht
    ======================== -->
    <div class="kld-box">
      <h3>Haftungsausschluss (Prototyp)</h3>
      <p class="kld-muted" style="margin:0;">
        Wir bemühen uns um sorgfältige technische Umsetzung. Dennoch können Inhalte unvollständig, veraltet oder fehlerhaft sein.
        Eine Haftung für Schäden, die aus der Nutzung dieses Prototyps entstehen, ist – soweit gesetzlich zulässig – ausgeschlossen.
      </p>

      <hr class="kld-hr">

      <h3 style="margin-top:0;">Haftung für Links</h3>
      <p class="kld-muted" style="margin:0;">
        Diese Website enthält Links zu externen Webseiten Dritter. Auf deren Inhalte haben wir keinen Einfluss.
        Für Inhalte externer Seiten ist stets der jeweilige Anbieter verantwortlich. Bei Bekanntwerden von Rechtsverletzungen werden entsprechende Links entfernt.
      </p>

      <hr class="kld-hr">

      <h3 style="margin-top:0;">Urheberrecht</h3>
      <p class="kld-muted" style="margin:0;">
        Inhalte dieses Prototyps (Layout/Code) unterliegen dem Urheberrecht des Projektteams bzw. der Universität.
        Inhalte aus der KuLaDig-Quelle (Texte/Bilder/Logos/Daten) unterliegen den Rechten der jeweiligen Rechteinhaber.
        Eine Weiterverwendung sollte nur im Rahmen der jeweiligen Nutzungsbedingungen erfolgen.
      </p>
    </div>

    <!-- =======================
         BOX: Kartenmaterial
    ======================== -->
    <div class="kld-box">
      <h3>Kartendienst / Kartenmaterial</h3>
      <p class="kld-muted" style="margin:0;">
        In diesem Prototyp werden (je nach Seite) Kartendaten über OpenStreetMap-basierte Kacheln eingebunden.
        Die konkrete Attribution wird in der Karte angezeigt.
      </p>
    </div>

    <!-- Stand-Datum -->
    <p class="kld-small">
      Stand: <?php echo date_i18n('d.m.Y'); ?>
    </p>

  </section>

  <?php
  return ob_get_clean(); // Gepufferten Output holen, Buffer leeren, als Shortcode-HTML zurückgeben
});
