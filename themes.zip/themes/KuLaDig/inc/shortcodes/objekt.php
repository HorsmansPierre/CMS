<?php
if (!defined('ABSPATH')) exit;

add_shortcode('kuladig_objekt', function ($atts) {

  /* =====================================================================
     Helper: Zeitraum-Text aus KuLaDig-Datumsfeldern bauen
     - wird später in den Metadaten angezeigt
  ====================================================================== */
  function kuladig_zeitraum($d) {
    if (!empty($d['AnfangVon']) && !empty($d['EndeBis'])) return $d['AnfangVon'].'–'.$d['EndeBis'];
    if (!empty($d['AnfangVon'])) return 'Beginn '.$d['AnfangVon'];
    if (!empty($d['AnfangBis'])) return 'Beginn vor '.$d['AnfangBis'];
    return '';
  }

  /* =====================================================================
     API: ID bestimmen + Objekt laden
     - ID kommt entweder aus Shortcode-Attribut [kuladig_objekt id="..."]
       oder aus der URL ?kuladig_id=...
  ====================================================================== */
  $a  = shortcode_atts(['id'=>''], $atts);
  $id = sanitize_text_field($a['id'] ?: ($_GET['kuladig_id'] ?? ''));
  if (!$id) return '';

  // Objekt-ID als "verwendet" registrieren (für deine Statistik/Tracking-Option)
  if (function_exists('kuladig_register_used_object_id')) {
    kuladig_register_used_object_id($id);
  }

  if (!$id) return '';

  // Objekt-Details von KuLaDig holen
  $data = kuladig_api_get('Objekt/'.$id);
  if (!$data) return '';

  $title = esc_html($data['Name'] ?? $id);
  $docs  = $data['Dokumente'] ?? [];

  /* =====================================================================
     Beschreibung & Autor
     - Autor steht teilweise als [author]...[/author] im Text (BBCode)
     - wird rausgezogen und separat angezeigt
  ====================================================================== */
  $raw = $data['Beschreibung'] ?? '';
  $author_name = '';

  if (preg_match('/\[author\](.*?)\[\/author\]/si', $raw, $m)) {
    $author_name = trim($m[1]);
    $raw = preg_replace('/\[author\].*?\[\/author\]/si', '', $raw);
  }

  // BBCode -> HTML (parse_bbcode kommt aus deiner Helper-Funktion)
  $desc = kuladig_parse_bbcode($raw);

  /* =====================================================================
     Autor-Zusatz
     - Datenherkunft (z.B. Quelle/Institution)
     - Jahr der letzten Änderung
  ====================================================================== */
  $author_extra = [];
  if (!empty($data['Datenherkunft']['Name'])) {
    $author_extra[] = $data['Datenherkunft']['Name'];
  }
  if (!empty($data['ZuletztGeaendert'])) {
    $author_extra[] = substr($data['ZuletztGeaendert'], 0, 4);
  }

  $author_full = trim(
    ($author_name ? $author_name : '') .
    ($author_extra ? ', ' . implode(', ', $author_extra) : '')
  );

  /* =====================================================================
     Bilder
     - erstes Thumbnail3Token wird "Hero"
     - restliche Thumbnails werden als Galerie angezeigt
  ====================================================================== */
  $hero = null;
  $thumbs = [];

  foreach ($docs as $d) {
    if (!empty($d['Thumbnail3Token'])) {
      if (!$hero) $hero = $d['Thumbnail3Token'];
      else $thumbs[] = $d['Thumbnail3Token'];
    }
  }

  /* =====================================================================
     Metadaten
     - Schlagwörter, Fachsichten, Adresse, Denkmalschutz, Methoden, Zeitraum, Literatur, Lizenz
  ====================================================================== */
  $schlagwoerter = array_values($data['Schlagwoerter'] ?? []);
  $fachsichten  = array_map(fn($f)=>$f[1], $data['Fachsichten'] ?? []);
  $adresse      = $data['Adresse'] ?? '';
  $denkmal      = $data['Denkmalschutz'][1] ?? '';
  $massstab     = $data['Erfassungsmassstab'][1] ?? '';
  $methoden     = array_map(fn($m)=>$m[1], $data['Erfassungsmethoden'] ?? []);
  $zeitraum     = kuladig_zeitraum($data);
  $literatur    = $data['LiteraturZitate'] ?? [];
  $lizenzText   = $data['Lizenz']['Ausgabetext'] ?? '';
  $kuladigUrl   = 'https://www.kuladig.de/Objektansicht/'.($data['Id'] ?? $id);

  /* =====================================================================
     GÄSTEBUCH – ohne neue Seiten (1 Container + comment_meta)
     Idee:
     - Es gibt genau 1 "Container-Post" (private Page), auf dem Kommentare erlaubt sind
     - Gästebuch-Einträge werden als WP-Comments dort gespeichert
     - Über comment_meta wird die Verbindung zur KuLaDig-Objekt-ID hergestellt
  ====================================================================== */

  // 1) Container-Post-ID holen/erstellen (einmalig)
  if (!function_exists('kuladig_gb_get_container_post_id')) {
    function kuladig_gb_get_container_post_id(): int {

      $opt_key = 'kld_guestbook_container_post_id';
      $existing = (int) get_option($opt_key, 0);
      if ($existing > 0 && get_post_status($existing)) {
        return $existing;
      }

      // Falls Option leer/kaputt: versuch Seite anhand Slug zu finden
      $slug = 'kuladig-gaestebuch';
      $p = get_page_by_path($slug, OBJECT, 'page');
      if ($p && !empty($p->ID)) {
        update_option($opt_key, (int)$p->ID, false);
        return (int)$p->ID;
      }

      // Neu anlegen (einmal)
      $new_id = wp_insert_post([
        'post_title'     => 'KuLaDig Gästebuch (System)',
        'post_name'      => $slug,
        'post_status'    => 'private',
        'post_type'      => 'page',
        'comment_status' => 'open',
      ], true);

      if (is_wp_error($new_id)) {
        return 0;
      }

      update_option($opt_key, (int)$new_id, false);
      return (int)$new_id;
    }
  }

  $gb_post_id = kuladig_gb_get_container_post_id();

  // 2) Absenden verarbeiten (POST -> Comment speichern)
  if ($gb_post_id && isset($_POST['gb_submit'], $_POST['gb_text'])) {

    if (isset($_POST['gb_nonce']) && wp_verify_nonce($_POST['gb_nonce'], 'kuladig_gb_' . $id)) {

      $name = sanitize_text_field($_POST['gb_name'] ?? '');
      $text = sanitize_textarea_field($_POST['gb_text'] ?? '');

      if ($name !== '' && $text !== '') {

        $cid = wp_insert_comment([
          'comment_post_ID' => $gb_post_id,
          'comment_author'  => $name,
          'comment_content' => $text,
          'comment_approved'=> 1,
          'comment_type'    => 'kuladig_guestbook', // sauber trennbar
        ]);

        if ($cid) {
          // Meta: welchem Objekt gehört der Eintrag?
          add_comment_meta($cid, 'kuladig_object_id', (string)$id, true);
          add_comment_meta($cid, 'kuladig_object_title', (string)($data['Name'] ?? ''), true);
        }
      }

      // Redirect (PRG Pattern), damit Reload nicht erneut postet
      wp_redirect(add_query_arg('gb_success', 1));
      exit;
    }
  }

  // 3) Kommentare fürs aktuelle Objekt laden (filter über meta_query)
  $comments = [];
  if ($gb_post_id) {
    $q = new WP_Comment_Query();
    $comments = $q->query([
      'post_id'     => $gb_post_id,
      'status'      => 'approve',
      'type'        => 'kuladig_guestbook',
      'orderby'     => 'comment_date_gmt',
      'order'       => 'DESC',
      'number'      => 200,
      'meta_query'  => [
        [
          'key'   => 'kuladig_object_id',
          'value' => (string)$id,
        ]
      ],
    ]);
  }

  // Output-Buffering: HTML sammeln und am Ende als Shortcode-String zurückgeben
  ob_start(); ?>


  <!-- =====================================================================
       HTML: Objektansicht (Text/Metadaten links, Medien/Karte rechts)
  ====================================================================== -->

  <div class="kuladig">
    <div class="kuladig-grid">

      <!-- ===============================================================
           LINKS: Titel + Beschreibung + Info-Boxen
      ================================================================ -->
      <div>

        <h1><?php echo $title; ?></h1>

        <?php echo $desc; ?>

        <?php if ($author_full): ?>
          <p><em>(<?php echo esc_html($author_full); ?>)</em></p>
        <?php endif; ?>

        <!-- 🔵 BOX 1: STECKBRIEF -->
        <div class="kuladig-box">
          <h4><?php echo $title; ?></h4>
          <?php if ($schlagwoerter): ?><p><strong>Schlagwörter:</strong> <?php echo implode(', ', $schlagwoerter); ?></p><?php endif; ?>
          <?php if ($fachsichten): ?><p><strong>Fachsichten:</strong> <?php echo implode(', ', $fachsichten); ?></p><?php endif; ?>
          <?php if ($adresse): ?><p><strong>Adresse:</strong> <?php echo esc_html($adresse); ?></p><?php endif; ?>
          <?php if ($denkmal): ?><p><strong>Gesetzlich geschütztes Kulturdenkmal:</strong> <?php echo esc_html($denkmal); ?></p><?php endif; ?>
          <?php if ($massstab): ?><p><strong>Erfassungsmaßstab:</strong> <?php echo esc_html($massstab); ?></p><?php endif; ?>
          <?php if ($methoden): ?><p><strong>Erfassungsmethode:</strong> <?php echo implode(', ', $methoden); ?></p><?php endif; ?>
          <?php if ($zeitraum): ?><p><strong>Historischer Zeitraum:</strong> <?php echo esc_html($zeitraum); ?></p><?php endif; ?>
        </div>

        <!-- 🔵 BOX 2: LITERATUR -->
        <?php if ($literatur): ?>
          <div class="kuladig-box">
            <h4>Literatur</h4>
            <?php foreach ($literatur as $l): ?>
              <div><?php echo kuladig_parse_bbcode($l); ?></div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <!-- 🔵 BOX 3: ZITIERWEISE -->
        <div class="kuladig-box">
          <h4>Empfohlene Zitierweise</h4>
          <p><strong>Urheberrechtlicher Hinweis:</strong> <?php echo esc_html($lizenzText); ?></p>
          <p><strong>Empfohlene Zitierweise:</strong>
            <?php echo esc_html($author_full); ?>, „<?php echo esc_html($title); ?>“.
            In: KuLaDig – Kultur.Landschaft.Digital.
            <a href="<?php echo esc_url($kuladigUrl); ?>"><?php echo esc_html($kuladigUrl); ?></a>
          </p>
        </div>

        <!-- 🔵 BOX 4: GÄSTEBUCH -->
        <div class="kuladig-box">
          <h4>Gästebuch</h4>

          <?php if (isset($_GET['gb_success'])): ?>
            <p><strong>Danke für dein Feedback!</strong></p>
          <?php endif; ?>

          <form method="post">
            <?php wp_nonce_field('kuladig_gb_' . $id, 'gb_nonce'); ?>

            <p>
              <label>Name</label><br>
              <input type="text" name="gb_name" required>
            </p>

            <p>
              <label>Nachricht</label><br>
              <textarea name="gb_text" required></textarea>
            </p>

            <button type="submit" name="gb_submit" class="kld-pill-btn kld-pill-sm kld-pill-blue">
              <span class="kld-pill-left" aria-hidden="true">✉️</span>
              <span class="kld-pill-right">
                <span class="kld-pill-text">Eintrag absenden</span>
                <span class="kld-pill-emoji" aria-hidden="true">✅</span>
              </span>
            </button>

          </form>

          <hr>

          <?php
          if (!empty($comments)):
            foreach ($comments as $c):
          ?>
              <p>
                <strong><?php echo esc_html($c->comment_author); ?></strong><br>
                <?php echo esc_html($c->comment_content); ?>
              </p>
          <?php
            endforeach;
          else:
            echo '<p><em>Noch keine Einträge.</em></p>';
          endif;
          ?>

        </div>

      </div>

      <!-- ===============================================================
           RECHTS: Medien + Karte + Galerie + Embed
      ================================================================ -->
      <div class="kuladig-media">

        <!-- Hero-Bild (erstes Thumbnail3Token) -->
        <?php if ($hero): ?>
          <div class="kuladig-media-item kuladig-media-hero">
            <img src="https://www.kuladig.de/api/public/Dokument?token=<?php echo esc_attr($hero); ?>">
          </div>
        <?php endif; ?>

        <!-- Karte (Shortcode wird hier direkt eingebettet) -->
        <div class="kuladig-object-map-block">
          <div class="kuladig-map-card">

            <!-- MAP -->
            <?php echo do_shortcode('[kuladig_karte]'); ?>

            <!-- MAP FOOTER -->
            <div class="kuladig-map-footer">
              <div class="kuladig-map-footer-action">

                <button type="button" class="kld-pill-btn kld-pill-sm kld-pill-green" onclick="focusCurrentObject()">
                  <span class="kld-pill-left" aria-hidden="true">📍</span>
                  <span class="kld-pill-right">
                    <span class="kld-pill-text">Aktuelles Objekt auf der Karte anzeigen</span>
                    <span class="kld-pill-emoji" aria-hidden="true">🗺️</span>
                  </span>
                </button>

              </div>
            </div>

          </div>
        </div>

        <!-- Galerie (weitere Thumbnails) -->
        <?php foreach ($thumbs as $t): ?>
          <div class="kuladig-media-item">
            <img src="https://www.kuladig.de/api/public/Dokument?token=<?php echo esc_attr($t); ?>">
          </div>
        <?php endforeach; ?>

        <!-- Embed-Beispiel (Sketchfab) -->
        <div class="kuladig-media-item kuladig-media-embed">
          <iframe
            src="https://sketchfab.com/models/2d6a416bd5bb45a0ab5efa71153c3147/embed"
            allowfullscreen>
          </iframe>
        </div>

      </div>

    </div>
  </div>

  <!-- =====================================================================
       HTML: Klick auf Bild -> groß anzeigen
  ====================================================================== -->
  <div class="kuladig-img-modal" id="kuladigImgModal">
    <span onclick="kuladigCloseImg()">×</span>
    <img id="kuladigImgModalImg">
  </div>

  <!-- =====================================================================
       JavaScript: Modal öffnen/schließen
       - Klick auf jedes Bild innerhalb ".kuladig" öffnet das Modal
  ====================================================================== -->
  <script>
    document.querySelectorAll('.kuladig img').forEach(img => {
      img.addEventListener('click', () => {
        const modal = document.getElementById('kuladigImgModal');
        document.getElementById('kuladigImgModalImg').src = img.src;
        modal.style.display = 'flex';
      });
    });

    function kuladigCloseImg(){
      document.getElementById('kuladigImgModal').style.display = 'none';
    }
  </script>


  <!-- =====================================================================
       JavaScript: Button "Aktuelles Objekt..." in die Action-Box verschieben
       - greift in die DOM-Struktur des [kuladig_karte]-Shortcodes ein
       - hängt den Button in die vorhandene Button-Gruppe und blendet Footer aus
  ====================================================================== -->
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const root = document.querySelector('.kuladig-object-map-block');
      if (!root) return;

      // Action-Box aus karte.php (enthält die 3 Buttons)
      const actionBox =
        root.querySelector('.kld-pill-group') ||
        root.querySelector('.kuladig-layout > div:first-child > div[style*="display:flex"]');

      // Der Button aus objekt.php ("Aktuelles Objekt...")
      const currentBtn = root.querySelector('.kuladig-map-footer-action .kld-pill-btn');

      // Footer (willst du danach nicht mehr separat sehen)
      const footer = root.querySelector('.kuladig-map-footer');

      if (actionBox && currentBtn) {
        actionBox.appendChild(currentBtn);          // ✅ rein in die Box
        if (footer) footer.style.display = 'none';  // ✅ Footer ausblenden
      }
    });
  </script>

<?php
  // Buffer ausgeben (Shortcode-Return)
  return ob_get_clean();
});
