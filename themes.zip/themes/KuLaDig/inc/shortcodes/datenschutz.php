<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_datenschutz title="Datenschutz"]
 * Datenschutz-Seite für Uni-Prototyp (WordPress-Theme KuLaDig)
 * - Layout: Boxen/Callout passend zu Suche/Newsfeed
 * - Inhalte: Hosting/Logs, API, Caching, Karte/LocalStorage, Formulare, Rechte, Kontakt
 */
add_shortcode('kuladig_datenschutz', function ($atts) {

  // Shortcode-Attribute
  $a = shortcode_atts([
    'title' => 'Datenschutz',
  ], $atts);

  // Titel aus Attributen (sauber als String)
  $title = trim((string)$a['title']);

  // Betreiber/Verantwortlicher
  $ctrl = [
    'name'  => 'Universitätsprojekt / Kuladig',
    'org'   => 'Hochschule Kaiserslautern Standort Zweibrücken',
    'addr'  => 'Amerikastraße 1, 66482 Zweibrücken',
    'email' => 'piho1002@stud.hs-kl.de',
    'phone' => '+352 621 311 275',
  ];

  // Offizielle KuLaDig-Datenschutzerklärung (externer Link)
  $official_privacy_url = 'https://www.kuladig.de/Datenschutz';

  // Interne Seite
  $urlMitmach = home_url('/mitmachen');

  ob_start(); ?> <!-- Startet Output-Buffering, damit HTML gesammelt und am Ende als String zurückgegeben wird (Shortcode) -->


  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- Wrapper: Datenschutz-Seite -->
  <section class="kld-ds-wrap">

    <!-- Überschrift -->
    <?php if ($title !== ''): ?>
      <h2 class="kld-ds-title"><?php echo esc_html($title); ?></h2>
    <?php endif; ?>

    <!-- Einleitung -->
    <p class="kld-ds-lead">
      Diese Datenschutzerklärung informiert darüber, welche personenbezogenen Daten bei der Nutzung dieses
      <strong>Uni-Prototyps</strong> verarbeitet werden. Der Prototyp lädt Inhalte (Objekte, Metadaten, Thumbnails)
      über öffentliche Schnittstellen (API) aus KuLaDig und stellt sie in einer eigenen Oberfläche dar.
    </p>

    <!-- Hinweis: offizielles KuLaDig -->
    <div class="kld-callout">
      <h3>Hinweis zum offiziellen KuLaDig-Portal</h3>
      <p style="margin:0; line-height:1.55;">
        Dieses Projekt ist <strong>nicht</strong> das offizielle KuLaDig-Portal. Die offizielle Datenschutzerklärung von KuLaDig findest du hier:
        <a href="<?php echo esc_url($official_privacy_url); ?>" target="_blank" rel="noopener">
          <?php echo esc_html($official_privacy_url); ?>
        </a>
      </p>
    </div>

    <!-- Zwei-Spalten-Layout (Desktop), untereinander (Mobile) -->
    <div class="kld-grid">

      <!-- Verantwortliche Stelle -->
      <div class="kld-box">
        <h3>1) Verantwortliche Stelle</h3>

        <!-- Key/Value-Liste (Definition List) -->
        <dl class="kld-kv">
          <dt>Anbieter / Verantwortlich</dt>
          <dd><?php echo esc_html($ctrl['name']); ?></dd>

          <dt>Organisation</dt>
          <dd><?php echo esc_html($ctrl['org']); ?></dd>

          <dt>Anschrift</dt>
          <dd><?php echo esc_html($ctrl['addr']); ?></dd>

          <dt>Kontakt</dt>
          <dd>
            <?php echo esc_html($ctrl['email']); ?>
            <?php if (!empty($ctrl['phone'])): ?><br><?php echo esc_html($ctrl['phone']); ?><?php endif; ?>
          </dd>
        </dl>
      </div>

      <!-- Server-Logfiles -->
      <div class="kld-box">
        <h3>2) Welche Daten verarbeiten wir beim Website-Aufruf?</h3>

        <p class="kld-muted" style="margin:0;">
          Beim Aufruf der Website verarbeitet der Server technisch bedingt Daten in sogenannten Server-Logfiles.
          Dazu können gehören: IP-Adresse, Datum/Uhrzeit, aufgerufene Seite/URL, Statuscode, Datenmenge,
          User-Agent (Browser), Referrer (vorherige Seite).
        </p>

        <ul class="kld-list">
          <li><strong>Zweck:</strong> Betrieb, Sicherheit, Fehleranalyse (z.B. Schutz vor Missbrauch).</li>
          <li><strong>Rechtsgrundlage:</strong> Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse am sicheren Betrieb).</li>
          <li><strong>Speicherdauer:</strong> abhängig von Hosting/Uni-Richtlinien; i.d.R. befristet.</li>
        </ul>
      </div>

    </div>

    <!-- API & externe Inhalte -->
    <div class="kld-box">
      <h3>3) API-Abrufe (KuLaDig) & Einbindung externer Inhalte</h3>

      <p class="kld-muted" style="margin:0;">
        Diese Website ruft Inhalte über die KuLaDig-API ab. Dabei wird technisch eine Verbindung zu Servern von KuLaDig aufgebaut.
        Zudem werden Vorschaubilder (Thumbnails) über KuLaDig-Ressourcen geladen (z.B. Dokument-Token).
      </p>

      <ul class="kld-list">
        <li>Beim Abruf können deine IP-Adresse und technische Header an den externen Server übertragen werden.</li>
        <li><strong>Zweck:</strong> Darstellung von Objekten/Medien in der Website-Oberfläche.</li>
        <li><strong>Rechtsgrundlage:</strong> Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an der Bereitstellung der Funktionen).</li>
      </ul>
    </div>

    <!-- Karte + localStorage -->
    <div class="kld-box">
      <h3>4) Karte (Leaflet / OpenStreetMap-Kacheln) & LocalStorage</h3>

      <p class="kld-muted" style="margin:0;">
        Für die Kartenfunktion wird Leaflet genutzt. Kartenkacheln werden in der Regel von einem OpenStreetMap-Tile-Server geladen.
        Dabei wird eine Verbindung zu einem externen Server aufgebaut (IP-Adresse/Browserdaten können übertragen werden).
      </p>

      <ul class="kld-list">
        <li><strong>Zweck:</strong> Kartendarstellung und Interaktion.</li>
        <li><strong>Rechtsgrundlage:</strong> Art. 6 Abs. 1 lit. f DSGVO.</li>
      </ul>

      <hr class="kld-hr">

      <p class="kld-muted" style="margin:0;">
        Zusätzlich speichert die Karten-Route (falls du sie nutzt) Daten im Browser über <span class="kld-code">localStorage</span>
        (z.B. ausgewählte Punkte/Route). Das passiert <strong>nur lokal</strong> im Browser, nicht serverseitig.
      </p>

      <ul class="kld-list">
        <li><strong>Zweck:</strong> Route/Marker über Seitenreload hinweg behalten.</li>
        <li><strong>Löschen:</strong> per Button „Route löschen“ oder Browser-Speicher löschen.</li>
      </ul>
    </div>

    <!-- Caching -->
    <div class="kld-box">
      <h3>5) Caching / technische Zwischenspeicherung</h3>

      <p class="kld-muted" style="margin:0;">
        Um Ladezeiten zu reduzieren, werden API-Antworten serverseitig zwischengespeichert (z.B. WordPress-Transients).
        Dabei werden in der Regel <strong>keine</strong> zusätzlichen personenbezogenen Daten gespeichert, sondern API-Inhalte/Antworten.
      </p>

      <ul class="kld-list">
        <li><strong>Zweck:</strong> Performance und Stabilität.</li>
        <li><strong>Rechtsgrundlage:</strong> Art. 6 Abs. 1 lit. f DSGVO.</li>
      </ul>
    </div>

    <!-- Mitmachen -->
    <div class="kld-box">
      <h3>6) Formulare („Mitmachen“) – welche Daten werden gespeichert?</h3>

      <p class="kld-muted" style="margin:0;">
        Wenn du über die Mitmachen-Seite einen Hinweis sendest, werden die eingegebenen Informationen serverseitig gespeichert,
        damit Admins sie später sichten und bearbeiten können.
      </p>

      <ul class="kld-list">
        <li><strong>Inhalte:</strong> Betreff, Name (optional), E-Mail (optional), Nachrichtentext.</li>
        <li><strong>Metadaten:</strong> IP-Adresse und User-Agent (zum Missbrauchsschutz/Fehleranalyse).</li>
        <li><strong>Anhänge (optional):</strong> hochgeladene Dateien werden auf dem Server gespeichert.</li>
        <li><strong>Kein E-Mail-Versand:</strong> Im Prototyp wird standardmäßig keine Mail verschickt.</li>
      </ul>

      <p class="kld-muted" style="margin-top:.75rem;">
        <strong>Rechtsgrundlage:</strong> Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an der Bearbeitung von Hinweisen)
        sowie ggf. Art. 6 Abs. 1 lit. a DSGVO (Einwilligung), wenn du freiwillig Kontaktdaten angibst.
      </p>

      <p class="kld-muted" style="margin-top:.5rem;">
        → <a class="kld-link" href="<?php echo esc_url($urlMitmach); ?>">Zur Mitmachen-Seite</a>
      </p>
    </div>

    <!-- Cookies -->
    <div class="kld-box">
      <h3>7) Cookies / Tracking</h3>

      <p class="kld-muted" style="margin:0;">
        In diesem Prototyp werden nach aktuellem Stand keine eigenen Tracking-Cookies (Analytics/Marketing) gesetzt.
        WordPress und einzelne Plugins können jedoch technisch notwendige Cookies verwenden (z.B. für Admin-Login im Backend).
      </p>
    </div>

    <!-- Empfänger -->
    <div class="kld-box">
      <h3>8) Empfänger, Übermittlung in Drittländer</h3>

      <p class="kld-muted" style="margin:0;">
        Je nach Nutzung werden Daten an folgende Empfänger übermittelt:
      </p>

      <ul class="kld-list">
        <li><strong>Hosting/Uni-IT:</strong> Serverbetrieb und Logfiles.</li>
        <li><strong>KuLaDig-Server:</strong> bei API-Abrufen und Bild-/Dokument-Requests.</li>
        <li><strong>Tile-Server (OpenStreetMap):</strong> bei Kartenkacheln.</li>
      </ul>

      <p class="kld-muted" style="margin-top:.5rem;">
        Eine Übermittlung in Drittländer kann nicht ausgeschlossen werden, wenn externe Dienste/Server außerhalb der EU betrieben werden.
      </p>
    </div>

    <!-- Rechte -->
    <div class="kld-box">
      <h3>9) Deine Rechte</h3>

      <p class="kld-muted" style="margin:0;">
        Du hast im Rahmen der DSGVO grundsätzlich folgende Rechte:
      </p>

      <ul class="kld-list">
        <li>Auskunft (Art. 15 DSGVO)</li>
        <li>Berichtigung (Art. 16 DSGVO)</li>
        <li>Löschung (Art. 17 DSGVO)</li>
        <li>Einschränkung der Verarbeitung (Art. 18 DSGVO)</li>
        <li>Datenübertragbarkeit (Art. 20 DSGVO)</li>
        <li>Widerspruch (Art. 21 DSGVO)</li>
        <li>Beschwerde bei einer Aufsichtsbehörde (Art. 77 DSGVO)</li>
      </ul>

      <p class="kld-muted" style="margin-top:.75rem;">
        Wenn du z.B. einen Hinweis über das Formular eingereicht hast und eine Löschung wünschst, nutze bitte die Kontaktadresse oben
        und nenne möglichst Datum/Betreff deines Hinweises, damit wir ihn zuordnen können.
      </p>
    </div>

    <!-- Stand-Datum -->
    <p class="kld-small">
      Stand: <?php echo date_i18n('d.m.Y'); ?>
    </p>

  </section>

  <?php
  return ob_get_clean(); // Holt den gepufferten HTML-Output, leert den Buffer und gibt ihn als String zurück (Shortcode-Return).
});
