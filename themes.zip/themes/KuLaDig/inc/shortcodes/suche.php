<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_suche]
 */

remove_shortcode('kuladig_suche');

add_shortcode('kuladig_suche', function () {

  // Output-Buffering: HTML/JS sammeln und am Ende als String zurückgeben (Shortcode)
  ob_start(); ?>

  <!-- Haupt-überschrift -->
  <div class="kld-page-head">
    <h1 class="kld-page-title">Suchen</h1>
  </div>

  <!-- Search-Wrapper -->
  <div class="kld-search-wrap" data-kld-search>

    <!-- Suchfeld -->
    <div class="kld-search-top">
      <input class="kld-q" placeholder="Suchbegriff" autocomplete="off">
    </div>

    <!-- 2-Spalten Layout: Ergebnisse links, Sidebar rechts -->
    <div class="kld-layout">

      <!-- Links: Ergebnisse -->
      <div class="kld-results">
        <p>Lade Objekte…</p>
      </div>

      <!-- Rechts: Filter + Sortierung + Karte -->
      <div class="kld-side">

        <!-- Filter-Box -->
        <div class="kld-box">
          <h4>Suchbegriff anwenden auf</h4>

          <div class="kld-apply-grid">
            <div class="kld-apply-toggles">

              <div class="kld-toggle">
                <span class="kld-toggle-label">📍 Ort</span>
                <span class="kld-switch">
                  <input type="checkbox" class="kld-filter-box" value="ort" aria-label="Filter Ort">
                  <span class="kld-slider"></span>
                </span>
              </div>

              <div class="kld-toggle">
                <span class="kld-toggle-label">🏛 Gemeinde️</span>
                <span class="kld-switch">
                  <input type="checkbox" class="kld-filter-box" value="gemeinde" aria-label="Filter Gemeinde️">
                  <span class="kld-slider"></span>
                </span>
              </div>

              <div class="kld-toggle">
                <span class="kld-toggle-label">📖 Schlagwort</span>
                <span class="kld-switch">
                  <input type="checkbox" class="kld-filter-box" value="schlagwort" aria-label="Filter Schlagwort">
                  <span class="kld-slider"></span>
                </span>
              </div>

              <div class="kld-toggle">
                <span class="kld-toggle-label">📚 Fachsicht</span>
                <span class="kld-switch">
                  <input type="checkbox" class="kld-filter-box" value="fachsicht" aria-label="Filter Fachsicht">
                  <span class="kld-slider"></span>
                </span>
              </div>

              <div class="kld-toggle">
                <span class="kld-toggle-label">📅 Datum</span>
                <span class="kld-switch">
                  <input type="checkbox" class="kld-filter-box" value="datum" aria-label="Filter Datum">
                  <span class="kld-slider"></span>
                </span>
              </div>

            </div>

            <!-- Hilfetext zum Datum-Filter -->
            <div class="kld-help kld-help-right">
              <strong><i>Datum-Beispiele:</i></strong><br>
              • <code><i>2024</i></code> (Jahr)<br>
              • <code><i>12.03.2024</i></code> (Tag.Monat.Jahr)<br>
              • <code><i>2024-2025</i></code> (Jahrbereich)
            </div>
          </div>
        </div>

        <!-- Sortierung -->
        <div class="kld-box">
          <h4>Sortieren nach</h4>
          <select class="kld-sort-select kld-sort">
            <option value="az" selected>Alphabetisch (A–Z)</option>
            <option value="za">Alphabetisch (Z–A)</option>
            <option value="newest">Neuste zuerst</option>
            <option value="oldest">Älteste zuerst</option>
            <option value="img">Mit Bild zuerst</option>
            <option value="random">Zufällig</option>
          </select>
        </div>

        <!-- Karte (wird als Shortcode eingebettet) -->
        <div class="kuladig-object-map-block">
          <?php echo do_shortcode('[kuladig_karte]'); ?>
        </div>

      </div>
    </div>
  </div>

  <!-- =====================================================================
       JavaScript:
  ====================================================================== -->
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      document.querySelectorAll('[data-kld-search]').forEach((root) => {

        const qInput  = root.querySelector('input.kld-q');
        const results = root.querySelector('.kld-results');
        const boxes   = root.querySelectorAll('.kld-filter-box');
        const sortSel = root.querySelector('select.kld-sort');

        if (!qInput || !results) return;

        let timer = null;
        let page = 1;

        // Fokus-Funktion: setzt Karte auf Objektposition, markiert aktiven Pin, scrollt zur Karte
        function focusOnMap(id) {
          id = String(id || '');

          const tryFocus = () => {
            const map    = window.kuladigMap;
            const marker = window.kuladigMarkers?.[id];
            const point  = window.kuladigPoints?.find(p => String(p.id) === id);

            if (!map || !marker || !point) return false;

            map.setView([point.lat, point.lng], 15, { animate: true });

            // Optional: Icon-State (grün für aktuelles Objekt) über die Map-API
            if (typeof window.kldSetCurrentId === 'function') {
              window.kldSetCurrentId(id);
            }

            // Optional: falls irgendwo eine toggleCurrent-Funktion existiert
            if (typeof toggleCurrent === 'function') {
              toggleCurrent(marker, true);
            }

            // Klick auslösen -> Preview-Box in der Karte aktualisiert sich
            try { marker.fire('click'); } catch (e) {}

            // Karte in den Viewport scrollen
            const mapBlock = root.querySelector('.kuladig-object-map-block');
            if (mapBlock) mapBlock.scrollIntoView({ behavior: 'smooth', block: 'start' });

            return true;
          };

          // Sofort versuchen (falls Map schon fertig ist)
          if (tryFocus()) return;

          // Wenn Map noch lädt: ein paar Mal retry
          let tries = 0;
          const t = setInterval(() => {
            tries++;
            if (tryFocus() || tries > 25) clearInterval(t);
          }, 120);
        }

        // Sammelt alle aktuellen UI-Parameter in URLSearchParams
        function collectParams() {
          const q = qInput.value.trim();
          const use = {};
          boxes.forEach(b => use[b.value] = b.checked ? 1 : 0);

          return new URLSearchParams({
            action: 'kuladig_live_search',
            q,
            sort: (sortSel?.value || 'az'),
            page: String(page),
            ...use
          });
        }

        // AJAX: HTML laden und in Ergebnisbereich schreiben
        function runSearch() {
          const params = collectParams();

          fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>?' + params.toString(), { credentials: 'same-origin' })
            .then(r => r.text())
            .then(html => { results.innerHTML = html; })
            .catch(() => { results.innerHTML = '<p>Fehler beim Laden.</p>'; });
        }

        // Reset auf Seite 1 und neu suchen (bei Query-/Filter-/Sort-Änderung)
        function resetAndSearch() {
          page = 1;
          runSearch();
        }

        // Verzögerung beim Tippen
        qInput.addEventListener('input', () => {
          clearTimeout(timer);
          timer = setTimeout(resetAndSearch, 250);
        });

        // Filter/Sortieren -> sofort neu laden
        boxes.forEach(b => b.addEventListener('change', resetAndSearch));
        sortSel?.addEventListener('change', resetAndSearch);

        // Klicks in Ergebnisliste (Seiten wechsel + "Auf Karte anzeigen") Funktion einbauen
        results.addEventListener('click', (e) => {

          // "Auf Karte anzeigen"
          const mapBtn = e.target.closest('.kld-map-btn');
          if (mapBtn) {
            e.preventDefault();
            const id = mapBtn.getAttribute('data-id');
            if (id) focusOnMap(id);
            return;
          }

          // Seiten wechsel
          const btn = e.target.closest('.kld-page-btn');
          if (!btn) return;

          const target = btn.getAttribute('data-page');
          if (!target) return;

          if (target === 'prev') page = Math.max(1, page - 1);
          else if (target === 'next') page = page + 1;
          else page = parseInt(target, 10) || 1;

          runSearch();
        });

        runSearch();
      });
    });
  </script>

  <?php
  // Shortcode-HTML zurückgeben
  return ob_get_clean();
});



/* =====================================================================
   Helper: Platzhalterbild (falls kein Thumbnail vorhanden ist)
====================================================================== */

if (!function_exists('kuladig_search_placeholder_img')) {
  function kuladig_search_placeholder_img() : string {
    return get_stylesheet_directory_uri() . '/assets/placeholder.jpg';
  }
}



/* =====================================================================
   Helper: Terms aus KuLaDig-Feldern normalisieren
====================================================================== */

if (!function_exists('kuladig_extract_terms_for_search')) {
  function kuladig_extract_terms_for_search($val) : array {
    $out = [];

    if (is_array($val)) {
      foreach ($val as $v) {
        if (is_array($v)) {
          if (isset($v[1])) $out[] = (string)$v[1];
          else $out[] = implode(' ', array_map('strval', $v));
        } else {
          $out[] = (string)$v;
        }
      }
    } elseif (is_string($val) || is_numeric($val)) {
      $out[] = (string)$val;
    }

    $out = array_map(fn($s) => trim(strip_tags((string)$s)), $out);
    return array_values(array_filter($out, fn($s) => $s !== ''));
  }
}



/* =====================================================================
   Helper: Datum-Query interpretieren
   - "2024" -> year
   - "2024-2025" -> year_range
   - "12.03.2024" oder "2024-03-12" -> date
   - sonst: text
====================================================================== */

if (!function_exists('kuladig_parse_date_query')) {
  function kuladig_parse_date_query(string $q) : array {
    $q = trim($q);

    if (preg_match('/^(\d{4})\s*-\s*(\d{4})$/', $q, $m)) {
      $y1 = (int)$m[1]; $y2 = (int)$m[2];
      if ($y2 < $y1) { $tmp=$y1; $y1=$y2; $y2=$tmp; }
      return ['type'=>'year_range', 'from'=>$y1, 'to'=>$y2];
    }

    if (preg_match('/^\d{4}$/', $q)) {
      return ['type'=>'year', 'year'=>(int)$q];
    }

    if (preg_match('/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/', $q, $m)) {
      $d = (int)$m[1]; $mo = (int)$m[2]; $y = (int)$m[3];
      $ts = strtotime(sprintf('%04d-%02d-%02d', $y, $mo, $d));
      if ($ts) return ['type'=>'date', 'ts'=>$ts];
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $q)) {
      $ts = strtotime($q);
      if ($ts) return ['type'=>'date', 'ts'=>$ts];
    }

    return ['type'=>'text'];
  }
}



/* =====================================================================
   Helper: gibt den "echten" Begriff zurück, der gematcht hat (für "Treffer: ...")
====================================================================== */

if (!function_exists('kuladig_find_hit_term')) {
  function kuladig_find_hit_term(array $terms, string $needle) : ?string {
    $needle = mb_strtolower($needle);
    foreach ($terms as $t) {
      $t = trim((string)$t);
      if ($t === '') continue;
      if (mb_stripos(mb_strtolower($t), $needle) !== false) return $t;
    }
    return null;
  }
}



/* =====================================================================
   Index: 200 Objekte vorbereiten (einmalig) für schnelle Live-Suche
   - baut Such-Index aus Master-Liste
   - cached als Transient (kld_search_index_v9)
====================================================================== */

if (!function_exists('kuladig_build_search_index')) {
  function kuladig_build_search_index() : array {

    // Basisliste bevorzugt über kuladig_site_objects()
    if (function_exists('kuladig_site_objects')) {
      $base = kuladig_site_objects();
    } else {
      $base = kuladig_api_get('Objekt', [
        'ObjektTyp'       => 'KuladigObjekt',
        'Seite'           => 0,
        'Seitengroesse'   => 200,
        'SortierModus'    => 'Aenderungsdatum',
        'Sortierrichtung' => 'Absteigend',
      ], 30 * MINUTE_IN_SECONDS);
    }

    $rows = [];
    if (is_array($base) && isset($base['Ergebnis']) && is_array($base['Ergebnis'])) {
      $rows = $base['Ergebnis'];
    } elseif (is_array($base)) {
      $rows = $base;
    }

    if (empty($rows)) return [];

    $index = [];

    foreach ($rows as $row) {
      $id = (string)($row['Id'] ?? '');
      if (!$id) continue;

      $name = (string)($row['Name'] ?? '');
      $descRaw = (string)($row['Beschreibung'] ?? '');
      $descPlain = trim(wp_strip_all_tags($descRaw));

      $changedTs = !empty($row['ZuletztGeaendert']) ? strtotime($row['ZuletztGeaendert']) : 0;
      $changedDMY = $changedTs ? date('d.m.Y', $changedTs) : '';
      $changedISO = $changedTs ? date('Y-m-d', $changedTs) : '';
      $changedYear= $changedTs ? date('Y', $changedTs) : '';

      // Liefert Felder für Ort/Gemeinde/Schlagwort/Fachsicht + ggf. weitere Thumbs
      $detail = kuladig_api_get('Objekt/' . $id, [], 12 * HOUR_IN_SECONDS);
      if (!is_array($detail)) $detail = [];

      // Thumbnail
      $thumbUrl = '';
      $hasThumb = false;

      if (!empty($row['ThumbnailToken'])) {
        $thumbUrl = 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($row['ThumbnailToken']);
        $hasThumb = true;
      } elseif (!empty($detail['Dokumente']) && is_array($detail['Dokumente'])) {
        foreach ($detail['Dokumente'] as $d) {
          if (!empty($d['Thumbnail3Token'])) {
            $thumbUrl = 'https://www.kuladig.de/api/public/Dokument?token=' . rawurlencode($d['Thumbnail3Token']);
            $hasThumb = true;
            break;
          }
        }
      }

      // Ort / Ortsteil
      $ortCandidates = [];
      foreach (['Ort','Ortsteil'] as $k) {
        if (!empty($detail[$k])) $ortCandidates = array_merge($ortCandidates, kuladig_extract_terms_for_search($detail[$k]));
      }

      // Gemeinde
      $gemeindeCandidates = [];
      foreach (['Gemeinde'] as $k) {
        if (!empty($detail[$k])) $gemeindeCandidates = array_merge($gemeindeCandidates, kuladig_extract_terms_for_search($detail[$k]));
      }

      // Fallback: Adresse
      if (!empty($detail['Adresse'])) {
        $addrTerms = kuladig_extract_terms_for_search($detail['Adresse']);
        if (!empty($addrTerms)) {
          $addr = implode(' | ', $addrTerms);
          $ortCandidates[] = $addr;
          $gemeindeCandidates[] = $addr;
        }
      }

      // Schlagwörter / Fachsichten
      $schlag = kuladig_extract_terms_for_search($detail['Schlagwoerter'] ?? ($detail['Schlagworte'] ?? []));
      $fach   = kuladig_extract_terms_for_search($detail['Fachsichten'] ?? []);

      $index[] = [
        'id'         => $id,
        'name'       => $name,
        'name_lc'    => mb_strtolower($name),
        'desc_plain' => $descPlain,

        'ort_terms'      => $ortCandidates,
        'gemeinde_terms' => $gemeindeCandidates,
        'schlag_terms'   => $schlag,
        'fach_terms'     => $fach,

        'ort_lc'      => mb_strtolower(implode(' | ', $ortCandidates)),
        'gemeinde_lc' => mb_strtolower(implode(' | ', $gemeindeCandidates)),
        'schlag_lc'   => mb_strtolower(implode(' | ', $schlag)),
        'fach_lc'     => mb_strtolower(implode(' | ', $fach)),

        'changed_ts'   => (int)$changedTs,
        'changed_dmy'  => $changedDMY,
        'changed_iso'  => $changedISO,
        'changed_year' => $changedYear,
        'changed_lc'   => mb_strtolower(trim($changedDMY . ' | ' . $changedISO . ' | ' . $changedYear)),

        'thumb'     => $thumbUrl,
        'has_thumb' => $hasThumb,
      ];
    }

    return $index;
  }
}

if (!function_exists('kuladig_get_search_index')) {
  function kuladig_get_search_index() : array {
    $cache_key = 'kld_search_index_v9';
    $cached = get_transient($cache_key);
    if (is_array($cached)) return $cached;

    $index = kuladig_build_search_index();
    set_transient($cache_key, $index, 30 * MINUTE_IN_SECONDS);

    return $index;
  }
}



/* =====================================================================
   Helper: Sortierung für Ergebnislisten
====================================================================== */

if (!function_exists('kuladig_sort_items')) {
  function kuladig_sort_items(array &$arr, string $sort) : void {

    if ($sort === 'random') {
      shuffle($arr);
      return;
    }

    usort($arr, function($a, $b) use ($sort) {
      $an = (string)($a['name'] ?? '');
      $bn = (string)($b['name'] ?? '');
      $at = (int)($a['changed_ts'] ?? 0);
      $bt = (int)($b['changed_ts'] ?? 0);
      $ah = !empty($a['has_thumb']);
      $bh = !empty($b['has_thumb']);

      switch ($sort) {
        case 'za':
          return strcasecmp($bn, $an);

        case 'newest':
          if ($at !== $bt) return $bt <=> $at;
          return strcasecmp($an, $bn);

        case 'oldest':
          if ($at !== $bt) return $at <=> $bt;
          return strcasecmp($an, $bn);

        case 'img':
          if ($ah !== $bh) return ($bh <=> $ah);
          return strcasecmp($an, $bn);

        case 'az':
        default:
          return strcasecmp($an, $bn);
      }
    });
  }
}



/* =====================================================================
   AJAX: Liefert HTML (kein JSON), das in der Suche direkt in .kld-results landet
====================================================================== */

if (!function_exists('kuladig_live_search')) {

  add_action('wp_ajax_kuladig_live_search', 'kuladig_live_search');
  add_action('wp_ajax_nopriv_kuladig_live_search', 'kuladig_live_search');

  function kuladig_live_search() {

    // Query & Grundparameter
    $q = sanitize_text_field($_GET['q'] ?? '');
    $needle = mb_strtolower($q);

    $sort = sanitize_text_field($_GET['sort'] ?? 'az');
    $page = max(1, (int)($_GET['page'] ?? 1));

    // Pro Seite "perPage" Objekte einblenden
    $perPage = 6;

    // Filter-Flags
    $useOrt      = !empty($_GET['ort']);
    $useGemeinde = !empty($_GET['gemeinde']);
    $useSchlag   = !empty($_GET['schlagwort']);
    $useFach     = !empty($_GET['fachsicht']);
    $useDatum    = !empty($_GET['datum']);

    $anyFilter = ($useOrt || $useGemeinde || $useSchlag || $useFach || $useDatum);

    // Datum-Interpretation nur dann, wenn Datum-Filter aktiv ist
    $dateQuery = $useDatum ? kuladig_parse_date_query($q) : ['type'=>'text'];

    // Index laden (cached)
    $index = kuladig_get_search_index();
    if (empty($index)) {
      echo '<p>Keine Ergebnisse.</p>';
      wp_die();
    }

    $items = [];

    // Alle Objekte durchgehen -> Score/Hits berechnen
    foreach ($index as $it) {

      $hits = [];
      $score = 0;

      // Ohne Filter: nur Titelmatch
      if (!$anyFilter) {
        if ($needle !== '' && mb_stripos($it['name_lc'], $needle) !== false) {
          $hits[] = ['label' => 'Titel', 'term' => $it['name']];
          $score = 1;
        }
      }
      // Mit Filter(n): pro aktivem Filter matchen und Trefferliste füllen
      else {
        if ($needle !== '') {

          if ($useOrt) {
            $term = kuladig_find_hit_term($it['ort_terms'] ?? [], $needle);
            if ($term !== null) $hits[] = ['label'=>'Ort', 'term'=>$term];
          }

          if ($useGemeinde) {
            $term = kuladig_find_hit_term($it['gemeinde_terms'] ?? [], $needle);
            if ($term !== null) $hits[] = ['label'=>'Gemeinde', 'term'=>$term];
          }

          if ($useSchlag) {
            $term = kuladig_find_hit_term($it['schlag_terms'] ?? [], $needle);
            if ($term !== null) $hits[] = ['label'=>'Schlagwort', 'term'=>$term];
          }

          if ($useFach) {
            $term = kuladig_find_hit_term($it['fach_terms'] ?? [], $needle);
            if ($term !== null) $hits[] = ['label'=>'Fachsicht', 'term'=>$term];
          }

          if ($useDatum) {
            $ts = (int)($it['changed_ts'] ?? 0);

            $ok = false;

            if ($dateQuery['type'] === 'year' && $ts) {
              $ok = ((int)date('Y', $ts) === (int)$dateQuery['year']);
            } elseif ($dateQuery['type'] === 'year_range' && $ts) {
              $y = (int)date('Y', $ts);
              $ok = ($y >= (int)$dateQuery['from'] && $y <= (int)$dateQuery['to']);
            } elseif ($dateQuery['type'] === 'date' && $ts) {
              $ok = (date('Y-m-d', $ts) === date('Y-m-d', (int)$dateQuery['ts']));
            } else {
              // Fallback: Textsuche im Datum-String (d.m.Y | Y-m-d | Y)
              $ok = ($needle !== '' && mb_stripos((string)($it['changed_lc'] ?? ''), $needle) !== false);
            }

            if ($ok) {
              $pretty = $it['changed_dmy'] ?: ($it['changed_iso'] ?: ($it['changed_year'] ?: $q));
              $hits[] = ['label'=>'Datum', 'term'=>$pretty];
            }
          }
        }

        $score = count($hits);
      }

      // Normalisierte Ausgabe-Objekte für Rendering
      $items[] = [
        'id'         => $it['id'],
        'name'       => $it['name'],
        'desc'       => $it['desc_plain'] ?? '',
        'thumb'      => $it['thumb'],
        'has_thumb'  => !empty($it['has_thumb']),
        'changed_ts' => (int)($it['changed_ts'] ?? 0),
        'score'      => $score,
        'hits'       => $hits,
      ];
    }

    // Treffer zuerst: Treffer/Rest getrennt sortieren
    if ($needle !== '') {
      $hitItems  = array_values(array_filter($items, fn($x) => (int)$x['score'] > 0));
      $restItems = array_values(array_filter($items, fn($x) => (int)$x['score'] <= 0));

      kuladig_sort_items($hitItems, $sort);
      kuladig_sort_items($restItems, $sort);

      $items = array_merge($hitItems, $restItems);
    } else {
      kuladig_sort_items($items, $sort);
    }

    // Seiten trennen
    $total = count($items);
    $totalPages = max(1, (int)ceil($total / $perPage));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $perPage;
    $pageItems = array_slice($items, $offset, $perPage);

    $placeholder = kuladig_search_placeholder_img();

    // =========================
    // HTML-Output (AJAX Response)
    // =========================
    echo '<div class="kuladig-newsfeed">';

    foreach ($pageItems as $obj) {

      $imgSrc = !empty($obj['thumb']) ? $obj['thumb'] : $placeholder;

      // Objekt-Link
      $url = esc_url(add_query_arg('kuladig_id', $obj['id'], home_url('/objekt')));

      echo '<div class="kuladig-news-item">';
      echo '<div class="kuladig-news-thumb"><img src="' . esc_url($imgSrc) . '" loading="lazy" alt=""></div>';

      echo '<div>';
      echo '<h4>' . esc_html($obj['name'] ?: 'Unbenanntes Objekt') . '</h4>';

      // Treffer-Pills
      if ($needle !== '' && !empty($obj['hits'])) {
        echo '<div class="kld-hitline">';
        foreach ($obj['hits'] as $h) {
          $label = $h['label'] ?? '';
          $term  = $h['term'] ?? '';
          echo '<span class="kld-hit">Treffer: ' . esc_html($label) . ' (' . esc_html($term) . ')</span>';
        }
        echo '</div>';
      }

      // Beschreibung
      if (!empty($obj['desc'])) {
        echo '<p class="kld-desc">' . esc_html($obj['desc']) . '</p>';
      }

      // Aktionen: Objekt öffnen + Karte fokussieren
      echo '<div class="kld-actions">';

      echo '<a class="kld-pill-btn kld-pill-sm kld-pill-link" href="' . $url . '">
              <span class="kld-pill-left" aria-hidden="true">📄</span>
              <span class="kld-pill-right">
                <span class="kld-pill-text">Zum Objekt</span>
                <span class="kld-pill-emoji" aria-hidden="true">↗️</span>
              </span>
            </a>';

      echo '<button type="button" class="kld-pill-btn kld-pill-sm kld-map-btn" data-id="' . esc_attr($obj['id']) . '">
              <span class="kld-pill-left" aria-hidden="true">🗺️</span>
              <span class="kld-pill-right">
                <span class="kld-pill-text">Auf Karte anzeigen</span>
                <span class="kld-pill-emoji" aria-hidden="true">📍</span>
              </span>
            </button>';

      echo '</div>';

      echo '</div>';
      echo '</div>';
    }

    echo '</div>';

    // Seiten trennung UI
    if ($totalPages > 1) {
      echo '<div class="kld-pagination">';

      $prevDisabled = ($page <= 1) ? 'disabled' : '';
      $nextDisabled = ($page >= $totalPages) ? 'disabled' : '';

      echo '<button class="kld-page-btn" data-page="prev" ' . $prevDisabled . '>‹</button>';

      $start = max(1, $page - 3);
      $end   = min($totalPages, $page + 3);

      if ($start > 1) {
        echo '<button class="kld-page-btn" data-page="1">1</button>';
        if ($start > 2) echo '<button class="kld-page-btn" disabled>…</button>';
      }

      for ($p = $start; $p <= $end; $p++) {
        $active = ($p === $page) ? 'active' : '';
        echo '<button class="kld-page-btn ' . $active . '" data-page="' . (int)$p . '">' . (int)$p . '</button>';
      }

      if ($end < $totalPages) {
        if ($end < $totalPages - 1) echo '<button class="kld-page-btn" disabled>…</button>';
        echo '<button class="kld-page-btn" data-page="' . (int)$totalPages . '">' . (int)$totalPages . '</button>';
      }

      echo '<button class="kld-page-btn" data-page="next" ' . $nextDisabled . '>›</button>';
      echo '</div>';
    }

    // AJAX-Ende
    wp_die();
  }
}
