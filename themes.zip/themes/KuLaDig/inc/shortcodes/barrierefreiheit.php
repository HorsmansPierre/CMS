<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_barrierefreiheit title="Barrierefreiheit"]
 * Erklärung zur Barrierefreiheit für Uni-Prototyp
 * - Layout (Boxen/Callout) passend zu Suche/Newsfeed
 * - Prototyp: externe Inhalte (KuLaDig API, Kartenkacheln), keine echten Nutzerkonten
 */
add_shortcode('kuladig_barrierefreiheit', function ($atts) {

  // Shortcode-Attribute (Fallback: Standard-Titel)
  $a = shortcode_atts([
    'title' => 'Barrierefreiheit',
  ], $atts);

  // Titel bereinigen
  $title = trim((string)$a['title']);

  // Betreiber/Verantwortliche dieses Prototyps
  $op = [
    'name'  => 'Universitätsprojekt / Kuladig',
    'org'   => 'Hochschule Kaiserslautern Standort Zweibrücken',
    'email' => 'piho1002@stud.hs-kl.de',
  ];

  // Offizielle KuLaDig-Seite zur Barrierefreiheit
  $official_access_url = 'https://www.kuladig.de/Barrierefreiheit';

  ob_start(); ?> <!-- Output-Buffering: HTML sammeln und am Ende als Shortcode-String zurückgeben -->

  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- Wrapper: Barrierefreiheits-Erklärung (Layout via CSS) -->
  <section class="kld-acc-wrap">

    <!-- Optionaler Titel (wenn nicht leer) -->
    <?php if ($title !== ''): ?>
      <h2 class="kld-acc-title"><?php echo esc_html($title); ?></h2>
    <?php endif; ?>

    <!-- Einleitungstext -->
    <p class="kld-acc-lead">
      Wir möchten, dass diese Website möglichst vielen Menschen zugänglich ist – unabhängig von individuellen Einschränkungen
      oder von der verwendeten Technik. Diese Seite beschreibt den Stand der Barrierefreiheit dieses
      <strong>Uni-Prototyps</strong> und wie du Barrieren melden kannst.
    </p>

    <!-- Callout: Abgrenzung zum offiziellen KuLaDig-Portal -->
    <div class="kld-callout">
      <h3>Hinweis zum offiziellen KuLaDig-Portal</h3>
      <p style="margin:0; line-height:1.55;">
        Dieses Projekt ist <strong>nicht</strong> das offizielle KuLaDig-Portal. Die offizielle Erklärung zur Barrierefreiheit von KuLaDig findest du hier:
        <a href="<?php echo esc_url($official_access_url); ?>" target="_blank" rel="noopener">
          <?php echo esc_html($official_access_url); ?>
        </a>
      </p>
    </div>

    <!-- Box: Stand der Vereinbarkeit -->
    <div class="kld-box">
      <h3>Stand der Vereinbarkeit</h3>

      <p class="kld-muted" style="margin:0;">
        Dieser Webauftritt ist ein Entwicklungs-/Studienprojekt. Wir orientieren uns an den Grundprinzipien der
        Barrierefreiheit (Wahrnehmbarkeit, Bedienbarkeit, Verständlichkeit und Robustheit), können aber nicht garantieren,
        dass alle Inhalte und Funktionen vollständig barrierefrei sind.
      </p>

      <p class="kld-muted" style="margin-top:.75rem;">
        <span class="kld-badge">Status</span>
        Teilweise vereinbar (Prototyp / laufende Weiterentwicklung)
      </p>
    </div>

    <!-- Grid: 2 Boxen nebeneinander (Desktop) -->
    <div class="kld-grid">

      <!-- Box: Was funktioniert gut -->
      <div class="kld-box">
        <h3>Was bereits gut funktioniert</h3>
        <ul class="kld-list">
          <li>Klare Seitenstruktur mit Überschriften und Abschnitten</li>
          <li>Kontrastreiche Buttons und Links im KuLaDig-Design</li>
          <li>Responsives Layout (mobile/desktop)</li>
          <li>FAQ-Bereiche über (Tastatur nutzbar)</li>
        </ul>
      </div>

      <!-- Box: Einschränkungen -->
      <div class="kld-box">
        <h3>Bekannte Einschränkungen</h3>
        <ul class="kld-list">
          <li>Kartenansicht: Interaktive Karten sind je nach Screenreader/Tastatur nur eingeschränkt nutzbar.</li>
          <li>Externe Inhalte (API/Thumbnails/Kartenkacheln) liegen außerhalb unseres direkten Einflusses.</li>
          <li>Einige dynamische Inhalte (AJAX) benötigen ggf. zusätzliche ARIA-Hinweise.</li>
          <li>Dokumente/Bilder aus Datenquellen können fehlende Alternativtexte haben.</li>
        </ul>
      </div>

    </div>

    <!-- Box: Bedienungshinweise -->
    <div class="kld-box">
      <h3>Bedienungshinweise</h3>
      <ul class="kld-list">
        <li><strong>Tastatur:</strong> Navigation mit Tab/Shift+Tab, Aktivieren mit Enter/Space.</li>
        <li><strong>Zoom:</strong> Browser-Zoom kann genutzt werden, ohne dass Inhalte abgeschnitten werden sollten.</li>
        <li><strong>Karte:</strong> Falls die Karte schwer nutzbar ist, nutze die Suche/Listenansichten als Alternative.</li>
      </ul>
    </div>

    <!-- Box: Feedback/Kontakt -->
    <div class="kld-box">
      <h3>Barriere melden / Feedback</h3>

      <p class="kld-muted" style="margin:0;">
        Wenn dir eine Barriere auffällt (z.B. Kontrast, Tastaturfokus, fehlende Beschriftung), sag uns bitte:
      </p>

      <ul class="kld-list">
        <li>Welche Seite/URL ist betroffen?</li>
        <li>Was genau funktioniert nicht (Schritte zur Reproduktion)?</li>
        <li>Welches Gerät/Betriebssystem/Browser nutzt du? (z.B. iOS/Safari, Windows/Firefox)</li>
        <li>Wenn möglich: Screenshot oder kurze Beschreibung</li>
      </ul>

      <!-- Optische Trennung -->
      <hr class="kld-hr">

      <!-- Kontaktblock -->
      <p class="kld-muted" style="margin:0;">
        Kontakt:
        <a class="kld-link" href="mailto:<?php echo esc_attr($op['email']); ?>">
          <?php echo esc_html($op['email']); ?>
        </a>
        <br>
        Betreiber: <?php echo esc_html($op['name']); ?> (<?php echo esc_html($op['org']); ?>)
      </p>
    </div>

    <!-- Box: Durchsetzungsverfahren/Schlichtung -->
    <div class="kld-box">
      <h3>Durchsetzungsverfahren / Schlichtung</h3>

      <p class="kld-muted" style="margin:0;">
        Da es sich um einen Uni-Prototyp handelt, erfolgt die Bearbeitung von Barriere-Meldungen im Rahmen des Projekts.
        Für offizielle KuLaDig-Inhalte und deren Verfahren beachte bitte die Hinweise auf der offiziellen KuLaDig-Seite.
      </p>

      <p class="kld-muted" style="margin-top:.6rem;">
        → <a class="kld-link" href="<?php echo esc_url($official_access_url); ?>" target="_blank" rel="noopener">
          Offizielle Erklärung zur Barrierefreiheit (KuLaDig)
        </a>
      </p>
    </div>

    <!-- Datum (lokalisiert) -->
    <p class="kld-small">
      Stand: <?php echo date_i18n('d.m.Y'); ?>
    </p>

  </section>

  <?php
  return ob_get_clean(); // Puffer holen + leeren, dann als Shortcode-Output zurückgeben
});
