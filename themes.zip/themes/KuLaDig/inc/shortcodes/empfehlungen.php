<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_empfehlungen]
 * 12 Karten, in 4er-Gruppen als Carousel
 */
add_shortcode('kuladig_empfehlungen', function () {

  /* =====================================================================
       PHP: Daten sammeln (12 Objekte mit Bild + Beschreibung)
  ====================================================================== */

  $items = [];

  // ✅ gleiche Liste wie Karte/Startseite (ache wird alle 3 Stunden erneuert
  $rows = kuladig_site_objects(3 * HOUR_IN_SECONDS);

  if (!empty($rows)) {
    foreach ($rows as $row) {

      // Objekt muss eine ID haben
      if (empty($row['Id'])) continue;

      // Erstes Bild (Thumbnail/Dokument) holen
      $img = kuladig_first_image_url($row);

      // Nur Items mit Bild anzeigen
      if ($img) {

        // Detail-Call (liefert z.B. Beschreibung)
        $detail = function_exists('kuladig_api_get')
          ? kuladig_api_get('Objekt/' . $row['Id'], [], 12 * HOUR_IN_SECONDS)
          : null;

        // Beschreibung aus Detail bevorzugen, sonst Fallback aus Liste
        $rawDesc = (string)($detail['Beschreibung'] ?? ($row['Beschreibung'] ?? ''));

        // [bbcode] / [irgendwas] grob entfernen
        $rawDesc = preg_replace('/\[[^\]]+\]/u', ' ', $rawDesc);

        // Entities dekodieren + nbsp raus + Whitespace glätten + Tags entfernen
        $clean = html_entity_decode($rawDesc, ENT_QUOTES, 'UTF-8');
        $clean = str_replace("\xC2\xA0", ' ', $clean);
        $clean = preg_replace('/\s+/u', ' ', $clean);
        $clean = trim(wp_strip_all_tags($clean));

        // Textlänge begrenzen
        $clean = wp_trim_words($clean, 220, ' …');

        // Finales Item fürs Carousel
        $items[] = [
          'img'  => $img,
          'name' => (string)($row['Name'] ?? ''),
          'desc' => $clean,
          'href' => home_url('/objektansicht/?kuladig_id=' . urlencode($row['Id'])),
        ];
      }

      // Max. 12 Karten
      if (count($items) >= 12) break;
    }
  }

  ob_start(); ?> <!-- Startet Output-Buffering, damit HTML gesammelt und am Ende als String zurückgegeben wird (Shortcode) -->


  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- Empfehlungen-Section (Full-Width Layout kommt über CSS #kld-rec-section) -->
  <section id="kld-rec-section" lang="de">

    <!-- Kopfbereich -->
    <div class="section-header">
      <div class="d-flex align-items-end justify-content-between mb-2">
        <div>
          <h3 class="mb-1">Empfehlungen</h3>
        </div>
      </div>
    </div>

    <?php if (!empty($items)) :

      // 4er-Gruppen für Carousel-Slides
      $chunks = array_chunk($items, 4); ?>

      <!-- Bootstrap Carousel (ohne Auto-Rotation) -->
      <div id="kld-rec" class="carousel slide" data-bs-ride="false">

        <!-- Slides -->
        <div class="carousel-inner">
          <?php foreach ($chunks as $i => $group): ?>
            <div class="carousel-item <?php echo $i === 0 ? 'active' : ''; ?>">

              <div class="container">
                <div class="row g-4">

                  <?php foreach ($group as $r):

                    // Ausgabe immer escapen (Sicherheit)
                    $name = esc_html($r['name']);
                    $desc = esc_html($r['desc']);
                    $href = esc_url($r['href']);
                    $img  = esc_url($r['img']); ?>

                    <!-- Card-Spalte -->
                    <div class="col-12 col-md-6 col-lg-3 d-flex">
                      <article class="card flex-fill h-100">

                        <!-- Bild -->
                        <img class="card-img-top" src="<?php echo $img; ?>" alt="<?php echo $name; ?>" loading="lazy">

                        <!-- Textbereich -->
                        <div class="card-body">
                          <h4 class="h6"><?php echo $name; ?></h4>

                          <!-- Beschreibung (Clamp passiert via CSS .kld-card-desc) -->
                          <p class="small mb-0 kld-card-desc" lang="de"><?php echo $desc; ?></p>

                          <!-- Ganze Card klickbar machen -->
                          <a class="stretched-link" href="<?php echo $href; ?>" aria-label="Mehr zu <?php echo esc_attr($name); ?>"></a>
                        </div>

                      </article>
                    </div>

                  <?php endforeach; ?>

                </div>
              </div>

            </div>
          <?php endforeach; ?>
        </div>

        <!-- Navigation Pfeile -->
        <button class="carousel-control-prev" type="button" data-bs-target="#kld-rec" data-bs-slide="prev">
          <span class="carousel-control-prev-icon"></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#kld-rec" data-bs-slide="next">
          <span class="carousel-control-next-icon"></span>
        </button>

      </div>

    <?php else: ?>

      <!-- Fallback: keine Empfehlungen -->
      <div class="container">
        <div class="alert alert-info mb-0">Keine Empfehlungen gefunden.</div>
      </div>

    <?php endif; ?>

  </section>
  
  <?php
  return ob_get_clean(); // Holt den gepufferten HTML-Output, leert den Buffer und gibt ihn als String zurück (Shortcode-Return).
});
