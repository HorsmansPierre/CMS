<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_hilfe title="Hilfe & FAQ"]
 * - Hilfe-Seite mit FAQ (Accordion via <details>)
 */
add_shortcode('kuladig_hilfe', function ($atts) {

  // Shortcode-Attribute
  $a = shortcode_atts([
    'title' => 'Hilfe & FAQ',
  ], $atts);

  // Titel aus Attributen (sauber als String)
  $title = trim((string)$a['title']);

  // =====================================================================
  // PHP: Links zu internen Seiten (Slugs ggf. anpassen)
  // =====================================================================
  $urlSuche   = home_url('/suche');
  $urlKarte   = home_url('/karte');
  $urlMitmach = home_url('/mitmachen');

  ob_start(); ?> <!-- Output-Buffering: HTML sammeln und am Ende als Shortcode-String zurückgeben -->

  <!-- =====================================================================
       HTML:
  ====================================================================== -->

  <!-- überschrift -->
  <div class="kld-page-head">
    <h1 class="kld-page-title">Hilfe & FAQ</h1>
  </div>

  <!-- Seiten-Wrapper -->
  <div class="kld-help-wrap">

    <!-- Einleitung -->
    <p class="kld-help-lead">
      Hier findest du eine kurze Anleitung zur Nutzung der Seite sowie Antworten auf häufige Fragen (FAQ).
      Wenn dir etwas auffällt oder Informationen fehlen: sende uns gern einen Hinweis über die Mitmachen-Seite.
    </p>

    <!-- Inhaltsverzeichnis -->
    <div class="kld-box" style="margin-bottom:1rem;">
      <h3>Inhalt</h3>
      <ul class="kld-toc">
        <li><a class="kld-pill" href="#kld-schnellstart">⚡ Schnellstart</a></li>
        <li><a class="kld-pill" href="#kld-suche">🔎 Suche</a></li>
        <li><a class="kld-pill" href="#kld-karte">🗺️ Karte</a></li>
        <li><a class="kld-pill" href="#kld-faq">❓ FAQ</a></li>
        <li><a class="kld-pill" href="#kld-probleme">🧩 Probleme lösen</a></li>
        <li><a class="kld-pill" href="#kld-feedback">✉️ Feedback</a></li>
      </ul>
    </div>

    <!-- Grid: Inhalte links/rechts, auf Desktop zweispaltig -->
    <div class="kld-help-grid">

      <!-- =======================
           BLOCK: Schnellstart
      ======================== -->
      <div class="kld-box kld-anchor" id="kld-schnellstart">
        <h3>⚡ Schnellstart</h3>

        <!-- Schritt 1 -->
        <div class="kld-step">
          <div class="n">1</div>
          <p>
            Öffne die <a class="kld-link" href="<?php echo esc_url($urlSuche); ?>">Suche</a>
            und gib einen Begriff ein (z.B. Ort, Gemeinde oder Schlagwort).
            Wähle rechts aus, worauf der Suchbegriff angewendet werden soll.
          </p>
        </div>

        <!-- Schritt 2 -->
        <div class="kld-step" style="margin-top:.7rem;">
          <div class="n">2</div>
          <p>
            Nutze die Karte, um Objekte räumlich zu entdecken. Marker anklicken → Vorschau öffnen → zum Objekt springen.
          </p>
        </div>

        <!-- Schritt 3 -->
        <div class="kld-step" style="margin-top:.7rem;">
          <div class="n">3</div>
          <p>
            Auf der Objektseite findest du Details, Medien und Verlinkungen. Wenn etwas nicht stimmt:
            <a class="kld-link" href="<?php echo esc_url($urlMitmach); ?>">Hinweis geben</a>.
          </p>
        </div>
      </div>

      <!-- =======================
           BLOCK: Feedback / Callout
      ======================== -->
      <div class="kld-callout kld-anchor" id="kld-feedback">
        <h3>✉️ Feedback & Hinweise</h3>
        <p style="margin:0 0 .75rem 0; line-height:1.55;">
          Du hast einen Fehler entdeckt oder möchtest Inhalte beisteuern (z.B. Fotos oder Ergänzungen)?
          Nutze die Mitmachen-Seite, damit Admins den Hinweis prüfen und später einpflegen können.
        </p>
        <p style="margin:0;">
          → <a href="<?php echo esc_url($urlMitmach); ?>">Zur Mitmachen-Seite</a>
        </p>
      </div>

      <!-- =======================
           BLOCK: Suche erklären
      ======================== -->
      <div class="kld-box kld-anchor" id="kld-suche">
        <h3>🔎 Suche – so funktioniert’s</h3>

        <!-- Hinweise als Liste -->
        <ul class="kld-muted" style="margin:0 0 0 1.1rem;">
          <li><strong>Suchbegriff</strong> eingeben (z.B. „Köln“, „Bergbau“, „2024“).</li>
          <li><strong>Filter</strong> auswählen (Ort, Gemeinde, Schlagwort, Fachsicht, Datum).</li>
          <li><strong>Sortierung</strong> nutzen (A–Z, Neuste zuerst, Mit Bild zuerst etc.).</li>
          <li>Mit „<strong>Auf Karte anzeigen</strong>“ kannst du Ergebnisse direkt auf der Karte fokussieren.</li>
        </ul>

        <!-- Beispiel für Datumsformate -->
        <p class="kld-muted" style="margin-top:.75rem;">
          Datumssuche: <code>2024</code> (Jahr), <code>12.03.2024</code> (Tag), <code>2024-2025</code> (Bereich)
        </p>
      </div>

      <!-- =======================
           BLOCK: Karte erklären
      ======================== -->
      <div class="kld-box kld-anchor" id="kld-karte">
        <h3>🗺️ Karte – Tipps</h3>

        <ul class="kld-muted" style="margin:0 0 0 1.1rem;">
          <li>Zoomen mit Mausrad / Touch-Gesten.</li>
          <li>Marker anklicken → Vorschau/Info öffnen.</li>
          <li>Wenn Marker „clustern“: hineinzoomen, um einzelne Marker zu sehen.</li>
        </ul>

        <!-- Optionaler Link zur Karte -->
        <?php if (!empty($urlKarte)): ?>
          <p class="kld-muted" style="margin-top:.75rem;">
            → <a class="kld-link" href="<?php echo esc_url($urlKarte); ?>">Zur Karte</a>
          </p>
        <?php endif; ?>
      </div>

      <!-- =======================
           BLOCK: FAQ (full width)
      ======================== -->
      <div class="kld-box kld-anchor" id="kld-faq" style="grid-column:1 / -1;">
        <h3>❓ Häufige Fragen (FAQ)</h3>

        <!-- Accordion via <details> (native + tastaturfreundlich) -->
        <div class="kld-faq">

          <details>
            <summary>
              <span class="q"><span class="icon">?</span>Warum sehe ich manchmal kein Bild?</span>
              <span class="chev">⌄</span>
            </summary>
            <div class="a">
              <p>
                Manche Objekte haben kein Vorschaubild (Thumbnail). In der Ergebnisliste wird dann ein Platzhalter angezeigt.
                Auf der Objektseite können trotzdem weitere Medien vorhanden sein.
              </p>
            </div>
          </details>

          <details>
            <summary>
              <span class="q"><span class="icon">?</span>Wie gebe ich einen Hinweis oder schlage ein neues Objekt vor?</span>
              <span class="chev">⌄</span>
            </summary>
            <div class="a">
              <p>
                Über die Mitmachen-Seite kannst du Hinweise, Ergänzungen oder neue Objektvorschläge einreichen.
                Die Einträge werden gespeichert und können später von Admins im Backend geprüft werden.
              </p>
              <p>→ <a class="kld-link" href="<?php echo esc_url($urlMitmach); ?>">Mitmachen öffnen</a></p>
            </div>
          </details>

          <details>
            <summary>
              <span class="q"><span class="icon">?</span>Kann ich direkt zu einem Objekt verlinken?</span>
              <span class="chev">⌄</span>
            </summary>
            <div class="a">
              <p>
                Ja. In der Regel über <code>/objekt/?kuladig_id=…</code>. Beim Klick auf „Zum Objekt →“ wird dieser Link automatisch erzeugt.
              </p>
            </div>
          </details>

          <details>
            <summary>
              <span class="q"><span class="icon">?</span>Ich erhalte keine Ergebnisse – was kann ich tun?</span>
              <span class="chev">⌄</span>
            </summary>
            <div class="a">
              <ul>
                <li>Prüfe, ob Filter aktiviert sind (Ort/Gemeinde/Schlagwort/Fachsicht/Datum).</li>
                <li>Teste eine allgemeinere Schreibweise (z.B. ohne Sonderzeichen).</li>
                <li>Setze die Sortierung zurück (A–Z).</li>
                <li>Wenn die Seite frisch gestartet ist: einmal neu laden, Cache kann gerade aufgebaut werden.</li>
              </ul>
            </div>
          </details>

        </div>
      </div>

      <!-- =======================
           BLOCK: Probleme lösen (full width)
      ======================== -->
      <div class="kld-box kld-anchor" id="kld-probleme" style="grid-column:1 / -1;">
        <h3>🧩 Probleme lösen</h3>

        <div class="kld-step">
          <div class="n">1</div>
          <p>
            <strong>Seite bleibt leer / lädt sehr lange:</strong>
            neu laden (F5) und 10–20 Sekunden warten. Beim ersten Aufruf wird Cache aufgebaut.
          </p>
        </div>

        <div class="kld-step" style="margin-top:.7rem;">
          <div class="n">2</div>
          <p>
            <strong>Karte zeigt nichts:</strong>
            prüfen, ob du sehr weit herausgezoomt bist. Reinzoomen hilft. Bei schwacher Verbindung dauert das Laden länger.
          </p>
        </div>

        <div class="kld-step" style="margin-top:.7rem;">
          <div class="n">3</div>
          <p>
            <strong>Objekt öffnet nicht:</strong>
            prüfe den Link mit <code>?kuladig_id=</code> und ob die ID korrekt ist. Sonst über Suche erneut öffnen.
          </p>
        </div>

        <p class="kld-muted" style="margin-top:.9rem;">
          Wenn du reproduzierbare Fehler findest, sende bitte einen Hinweis (idealerweise mit Screenshot & Link).
          → <a class="kld-link" href="<?php echo esc_url($urlMitmach); ?>">Mitmachen</a>
        </p>
      </div>

    </div>
  </div>

  <?php
  return ob_get_clean(); // Gepufferten Output holen, Buffer leeren, als Shortcode-HTML zurückgeben
});
