<?php
if (!defined('ABSPATH')) exit;

/* =====================================================================
   KuLaDig API Helper:
   - Holt Daten aus der öffentlichen KuLaDig API
   - Nutzt WordPress Transients als Cache
====================================================================== */

/** Mini-Client für die öffentliche KuLaDig API */
function kuladig_api_get($path, $args = [], $ttl = 6 * HOUR_IN_SECONDS) {

  // Basis-URL der öffentlichen API
  $base = 'https://www.kuladig.de/api/public/';

  // Query-Parameter sortieren → stabiler Cache-Key (Reihenfolge egal)
  ksort($args);

  // Cache-Key: eindeutig je Endpoint + Parameter
  $cache_key = 'kuladig_' . md5($path . json_encode($args));

  // Wenn Cache vorhanden: sofort zurückgeben (spart Requests)
  if ($cached = get_transient($cache_key)) return $cached;

  // URL bauen: base + path + args als Querystring
  $url  = add_query_arg($args, trailingslashit($base) . ltrim($path, '/'));

  // Request an die API (Timeout 15s)
  $resp = wp_remote_get($url, ['timeout' => 15]);

  // Fehler/Status prüfen (nur 200 OK akzeptieren)
  if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) return null;

  // JSON-Body in Array umwandeln
  $data = json_decode(wp_remote_retrieve_body($resp), true);

  // Wenn Daten valide: in Cache legen (TTL) und zurückgeben
  if ($data) set_transient($cache_key, $data, $ttl);

  return $data;
}
