<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [kuladig_anmelden title="Anmelden"]
 * Fake-Login UI (Demo) – keine echten Nutzer, kein Versand, keine Speicherung.
 */
add_shortcode('kuladig_anmelden', function ($atts) {
  ob_start(); ?> <!-- Startet Output-Buffering, damit HTML gesammelt und am Ende als String zurückgegeben wird (Shortcode) -->

    
  <!-- =====================================================================
       HTML:
  ====================================================================== -->
      
  <!-- Auth-Wrapper: komplette Demo-Login-Oberfläche -->
  <section class="kld-auth-wrap" id="kld-auth">
      
  <!-- Überschrift -->
  <h2 class="kld-auth-title">Anmelden</h2>

    <div class="kld-auth-card">

      <!-- Status-/Hinweisbox (wird per JS befüllt) -->
      <div class="kld-alert" id="kld-auth-alert" role="status" aria-live="polite"></div>

      <!-- Tabs: Panel-Navigation -->
      <div class="kld-auth-tabs" aria-label="Anmelden Navigation">

        <button type="button" class="kld-pill-btn kld-tab kld-pill-blue active" data-panel="login">
          <span class="kld-pill-left" aria-hidden="true">🔐</span>
          <span class="kld-pill-right">
            <span class="kld-pill-text">Anmelden</span>
            <span class="kld-pill-emoji" aria-hidden="true">↘️</span>
          </span>
        </button>

        <button type="button" class="kld-pill-btn kld-tab kld-pill-gray" data-panel="forgot">
          <span class="kld-pill-left" aria-hidden="true">❓</span>
          <span class="kld-pill-right">
            <span class="kld-pill-text">Passwort vergessen</span>
            <span class="kld-pill-emoji" aria-hidden="true">↘️</span>
          </span>
        </button>

        <button type="button" class="kld-pill-btn kld-tab kld-pill-gray" data-panel="change">
          <span class="kld-pill-left" aria-hidden="true">🔁</span>
          <span class="kld-pill-right">
            <span class="kld-pill-text">Passwort ändern</span>
            <span class="kld-pill-emoji" aria-hidden="true">↘️</span>
          </span>
        </button>

      </div>

      <!-- =======================
           PANEL: LOGIN
      ======================== -->
      <div class="kld-auth-panel active" id="kld-panel-login">
        <form class="kld-auth-form" data-action="login" autocomplete="off">

            <!-- Benutzer Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-user">Benutzer</label>
            <input
              id="kld-user"
              name="user"
              type="text"
              placeholder="z.B. vorname.nachname"
              autocomplete="off"
            >
          </div>

            <!-- Passwort Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-pass">Passwort</label>
            <input
              id="kld-pass"
              name="pass"
              type="password"
              placeholder="••••••••••"
              autocomplete="new-password"
            >
          </div>

            <!-- Buttons und links -->
          <div class="kld-auth-actions">
            <!-- Primäraktion -->
            <button type="submit" class="kld-pill-btn kld-pill-blue">
              <span class="kld-pill-left" aria-hidden="true">✅</span>
              <span class="kld-pill-right">
                <span class="kld-pill-text">Anmelden</span>
                <span class="kld-pill-emoji" aria-hidden="true">↗️</span>
              </span>
            </button>

            <!-- Sekundärnavigation -->
            <button class="kld-link" type="button" data-go="change">Passwort ändern</button>
            <button class="kld-link" type="button" data-go="forgot">Passwort vergessen?</button>
          </div>

            <!-- Hinweis -->
          <p class="kld-note">
            Hinweis: Das ist nur eine Demo-Oberfläche. Es gibt keine echten Benutzerkonten –
            daher werden keine Daten geprüft oder gespeichert.
          </p>
        </form>
      </div>

      <!-- =======================
           PANEL: FORGOT PASSWORD
      ======================== -->
      <div class="kld-auth-panel" id="kld-panel-forgot">
        <form class="kld-auth-form" data-action="forgot" autocomplete="off">

            <!-- Benutzer Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-forgot-user">Benutzer (optional)</label>
            <input
              id="kld-forgot-user"
              name="user"
              type="text"
              placeholder="Benutzername"
              autocomplete="off"
            >
          </div>

            <!-- Email Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-forgot-mail">E-Mail (optional)</label>
            <input
              id="kld-forgot-mail"
              name="email"
              type="email"
              placeholder="name@uni.de"
              autocomplete="off"
            >
          </div>

            <!-- Reset-Link Button -->
          <div class="kld-auth-actions">
            <button type="submit" class="kld-pill-btn kld-pill-blue">
              <span class="kld-pill-left" aria-hidden="true">✉️</span>
              <span class="kld-pill-right">
                <span class="kld-pill-text">Reset-Link anfordern</span>
                <span class="kld-pill-emoji" aria-hidden="true">↗️</span>
              </span>
            </button>

            <!-- Zurück zum Login Button -->
            <button class="kld-link" type="button" data-go="login">Zurück zum Login</button>
          </div>

            <!-- Hinweis -->
          <p class="kld-note">
            Demo: Es wird kein Reset-Link verschickt. Diese Funktion ist nur als Platzhalter für das Design gedacht.
          </p>
        </form>
      </div>

      <!-- =======================
           PANEL: CHANGE PASSWORD
      ======================== -->
      <div class="kld-auth-panel" id="kld-panel-change">
        <form class="kld-auth-form" data-action="change" autocomplete="off">

            <!-- Benutzer Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-change-user">Benutzer</label>
            <input
              id="kld-change-user"
              name="user"
              type="text"
              placeholder="Benutzername"
              autocomplete="off"
            >
          </div>

            <!-- Altes Passwort Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-old-pass">altes Passwort</label>
            <input
              id="kld-old-pass"
              name="old"
              type="password"
              placeholder="••••••••••"
              autocomplete="new-password"
            >
          </div>

            <!-- Neues Passwort Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-new-pass">neues Passwort</label>
            <input
              id="kld-new-pass"
              name="new"
              type="password"
              placeholder="••••••••••"
              autocomplete="new-password"
            >
          </div>

            <!-- Neues Passwort wiederholen Label & Text Field -->
          <div class="kld-auth-row">
            <label for="kld-new-pass2">neues Passwort wiederholen</label>
            <input
              id="kld-new-pass2"
              name="new2"
              type="password"
              placeholder="••••••••••"
              autocomplete="new-password"
            >
          </div>

            <!-- Passwort ändern Button -->
          <div class="kld-auth-actions">
            <button type="submit" class="kld-pill-btn kld-pill-green">
              <span class="kld-pill-left" aria-hidden="true">🔒</span>
              <span class="kld-pill-right">
                <span class="kld-pill-text">Passwort ändern</span>
                <span class="kld-pill-emoji" aria-hidden="true">✅</span>
              </span>
            </button>

            <!-- Zurück zum Login Button -->
            <button class="kld-link" type="button" data-go="login">Zurück zum Login</button>
          </div>

            <!-- Hinweis -->
          <p class="kld-note">
            Demo: Es wird nichts geändert. Diese Oberfläche ist nur ein UI-Platzhalter.
          </p>
        </form>
      </div>

    </div>
  </section>





  <!-- =====================================================================
       JavaScript:
  ====================================================================== -->
  <script>
    (function () {
      const root = document.getElementById('kld-auth');
      if (!root) return;

      // Hinweisbox (wird bei Aktionen eingeblendet)
      const alertBox = document.getElementById('kld-auth-alert');

      // Meldung anzeigen (und sichtbar schalten)
      function showAlert(msg) {
        if (!alertBox) return;
        alertBox.textContent = msg;
        alertBox.classList.add('show');
      }

      // Zwischen Panels umschalten + Tabs markieren
      function setPanel(panel) {
        // Tab-Status aktualisieren
        root.querySelectorAll('.kld-tab').forEach(b => {
        const isActive = b.getAttribute('data-panel') === panel;

        b.classList.toggle('active', isActive);

        // Farben umschalten: aktiv blau, sonst grau
        b.classList.toggle('kld-pill-blue', isActive);
        b.classList.toggle('kld-pill-gray', !isActive);
      });


        // Panels ein-/ausblenden
        root.querySelectorAll('.kld-auth-panel').forEach((p) => p.classList.remove('active'));
        const target = document.getElementById('kld-panel-' + panel);
        if (target) target.classList.add('active');

        // Beim Wechsel: Alert ausblenden
        if (alertBox) alertBox.classList.remove('show');
      }

      // Klicks delegieren (Tabs + "Zurück"-Links) / Buttons, ... eine Funktiom geben
      root.addEventListener('click', (e) => {
        const tab = e.target.closest('.kld-tab');
        if (tab) {
          e.preventDefault();
          setPanel(tab.getAttribute('data-panel'));
          return;
        }

        const go = e.target.closest('[data-go]');
        if (go) {
          e.preventDefault();
          setPanel(go.getAttribute('data-go'));
          return;
        }
      });

      // Formulare: Submit wird abgefangen (Demo-Meldung statt echter Aktion)
      root.querySelectorAll('.kld-auth-form').forEach((form) => {
        form.addEventListener('submit', (e) => {
          e.preventDefault();

          const action = form.getAttribute('data-action');

          if (action === 'login') {
            showAlert('Demo: Anmelden ist deaktiviert (keine echten Benutzer in dieser Website).');
          } else if (action === 'forgot') {
            showAlert('Demo: Passwort-Reset ist deaktiviert. Es wird keine E-Mail verschickt.');
          } else if (action === 'change') {
            showAlert('Demo: Passwort ändern ist deaktiviert. Es wird nichts gespeichert.');
          } else {
            showAlert('Demo: Aktion nicht verfügbar.');
          }

          //Formular zurücksetzen, damit nichts "gespeichert" wirkt
          try { form.reset(); } catch (e) {}
        });
      });
    })();
  </script>

  <?php
  return ob_get_clean(); // Holt den gepufferten HTML-Output, leert den Buffer und gibt ihn als String zurück (Shortcode-Return).
});
