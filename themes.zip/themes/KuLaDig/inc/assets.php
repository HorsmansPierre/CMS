<?php
if (!defined('ABSPATH')) exit;

/**
 * Assets laden (CSS/JS)
 * - Wird von WordPress im Frontend aufgerufen, sobald wp_enqueue_scripts läuft.
 */
add_action('wp_enqueue_scripts', function () {

  /* =====================================================================
     Basis: Theme-Pfade
  ====================================================================== */
  $theme_uri = get_stylesheet_directory_uri(); // URL zum (Child-)Theme

  /* =====================================================================
     Framework: Bootstrap (CSS + JS)
  ====================================================================== */
  wp_enqueue_style(
    'bootstrap', // Handle (Name)
    $theme_uri . '/assets/bootstrap/bootstrap.min.css', // Datei-URL
    [],   // Abhängigkeiten
    null  // Version (null = WP hängt keine Version an)
  );

  wp_enqueue_script(
    'bootstrap', // Handle
    $theme_uri . '/assets/bootstrap/bootstrap.bundle.min.js', // Datei-URL
    ['jquery'], // Abhängigkeiten (hier: jQuery)
    null,       // Version
    true        // im Footer laden
  );

  /* =====================================================================
     Theme: globale Styles (style.css)
  ====================================================================== */
  wp_enqueue_style(
    'kuladig-style',                       // Handle
    $theme_uri . '/assets/css/style.css',  // Datei-URL
    ['bootstrap'],                         // Lädt nach Bootstrap
    null
  );

  /* =====================================================================
     Map: Leaflet (von CDN)
  ====================================================================== */
  wp_enqueue_style(
    'leaflet-css',
    'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
  );

  wp_enqueue_script(
    'leaflet-js',
    'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
    [],
    null,
    true
  );

  /* =====================================================================
     Feature-CSS: einzelne Seiten/Module
     - Alle hängen an kuladig-style (damit globale Regeln vorher da sind)
     - Version via filemtime() => Browser lädt neu, wenn Datei geändert wurde
  ====================================================================== */
  $base_dir = get_stylesheet_directory();
  $base_uri = get_stylesheet_directory_uri() . '/assets/css/';

  $css_files = [
    'header.css'          => 'kuladig-header',
    'footer.css'          => 'kuladig-footer',
    'anmelden.css'        => 'kuladig-anmelden',
    'barrierefreiheit.css'=> 'kuladig-barrierefreiheit',
    'datenschutz.css'     => 'kuladig-datenschutz',
    'empfehlungen.css'    => 'kuladig-empfehlungen',
    'hero.css'            => 'kuladig-hero',
    'hilfe.css'           => 'kuladig-hilfe',
    'impressum.css'       => 'kuladig-impressum',
    'karte.css'           => 'kuladig-karte',
    'kategorien.css'      => 'kuladig-kategorien',
    'mitmachen.css'       => 'kuladig-mitmachen',
    'newsfeed.css'        => 'kuladig-newsfeed',
    'objekt.css'          => 'kuladig-objekt',
    'suche.css'           => 'kuladig-suche',
  ];

  foreach ($css_files as $file => $handle) {
    $path = $base_dir . '/assets/css/' . $file;

    wp_enqueue_style(
      $handle,                 // Handle
      $base_uri . $file,       // Datei-URL
      ['kuladig-style'],       // Abhängigkeit: globale Styles
      filemtime($path)         // Version = Änderungszeit (Cache-Busting)
    );
  }
});
