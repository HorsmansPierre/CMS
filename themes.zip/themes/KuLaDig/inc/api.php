<?php
if (!defined('ABSPATH')) exit;

/* =====================================================================
   KuLaDig API: Mini-Client + Master-Objektliste
   - API Responses werden per Transient gecached
   - Master-Liste liefert die “neusten Änderungen” (wie Karte/Startseite)
====================================================================== */


/* =====================================================================
   Mini-Client: Öffentliche KuLaDig API abfragen (mit Cache)
====================================================================== */
/* Alle 6h wird der cache neugebaut */ 
function kuladig_api_get($path, $args = [], $ttl = 6 * HOUR_IN_SECONDS) {

  // Basis-URL der öffentlichen API
  $base = 'https://www.kuladig.de/api/public/';

  // Args sortieren → stabiler Cache-Key (gleiche Args = gleicher Key)
  ksort($args);

  // Cache-Key aus Pfad + Args bauen
  $cache_key = 'kuladig_' . md5($path . json_encode($args));

  // 1) Cache: wenn vorhanden, sofort zurückgeben
  $cached = get_transient($cache_key);
  if ($cached) return $cached;

  // 2) URL aufbauen: base + path + query args
  $url  = add_query_arg($args, trailingslashit($base) . ltrim($path, '/'));

  // 3) HTTP Request (Timeout, damit es nicht “hängt”)
  $resp = wp_remote_get($url, ['timeout' => 15]);

  // Fehler / kein 200 → null zurück (Caller entscheidet was passiert)
  if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) {
    return null;
  }

  // JSON in Array dekodieren
  $data = json_decode(wp_remote_retrieve_body($resp), true);

  // 4) Cache: nur wenn Daten valide sind
  if ($data) {
    set_transient($cache_key, $data, $ttl);
  }

  return $data;
}


/* =====================================================================
   Master-Liste: Neuste geänderte Objekte (für Seite/Karte/Suche identisch)
====================================================================== */
/* Alle 6h wird der cache neugebaut */ 
function kuladig_site_objects($ttl = 6 * HOUR_IN_SECONDS) {

  // Zielmenge
  $want = 300;

  // Pro Request (viele APIs cappen bei ~100)
  $per  = 100;

  // Sammel-Array für alle Ergebnisse
  $all  = [];

  // Seitenweise holen, bis genug da ist oder API nichts mehr liefert
  $pages = (int) ceil($want / $per);
  for ($page = 0; $page < $pages; $page++) {

    // Query-Parameter: Sortierung nach Änderungsdatum absteigend
    $args = [
      'Seite'           => $page,
      'Seitengroesse'   => $per,
      'SortierModus'    => 'Aenderungsdatum',
      'Sortierrichtung' => 'Absteigend',
    ];

    // API Call
    $res = kuladig_api_get('Objekt', $args, $ttl);

    // Wenn kein Ergebnis-Array kommt: abbrechen
    if (empty($res['Ergebnis']) || !is_array($res['Ergebnis'])) {
      break;
    }

    // Ergebnisse anhängen
    $all = array_merge($all, $res['Ergebnis']);

    // Wenn genug gesammelt: abbrechen
    if (count($all) >= $want) {
      break;
    }
  }

  // Exakt “want” Elemente zurückgeben (falls mehr gesammelt wurde)
  return array_slice($all, 0, $want);
}
