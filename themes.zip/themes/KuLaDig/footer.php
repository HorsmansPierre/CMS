</main>

<!-- Footer: kompletter Seiten-Footer -->
<footer id="site-footer" class="footer-ks mt-5">
  <!-- Bootstrap Container + vertikales Padding -->
  <div class="container py-5">

    <!-- 2-Spalten Layout: Links (Infos) / Rechts (Logos) -->
    <div class="row g-4 align-items-start">

      <!-- =========================
           LINKS: Informationen
      ========================== -->
      <div class="col-12 col-lg-4">
        <!-- Information überschrift -->
        <h4 class="h6 text-uppercase mb-3 text-light fw-semibold">Informationen</h4>

        <!-- Linkliste -->
        <ul class="list-unstyled mb-0 footer-links">

          <!-- Externe Links (führen zu neuen Tabs) -->
          <li>
            <a
              href="https://www.lvr.de/de/nav_main/kultur/kulturlandschaft/unsere_themen/kuladignw/presse_5/presse_6.jsp"
              target="_blank"
              rel="noopener"
            >
              Informationsmaterial
            </a>
          </li>

          <li>
            <a
              href="https://www.lvr.de/de/nav_main/kultur/kulturlandschaft/unsere_themen/kuladignw/partner/partner_1.jsp"
              target="_blank"
              rel="noopener"
            >
              Partner
            </a>
          </li>

          <li>
            <a
              href="https://www.lvr.de/de/nav_main/kultur/kulturlandschaft/unsere_themen/kuladignw/kontakt_12/kontakt_13.jsp"
              target="_blank"
              rel="noopener"
            >
              Kontakt
            </a>
          </li>

          <!-- Interne Seiten (WordPress) -->
          <li><a href="<?php echo esc_url(home_url('/impressum')); ?>">Impressum</a></li>
          <li><a href="<?php echo esc_url(home_url('/datenschutz')); ?>">Datenschutz</a></li>
          <li><a href="<?php echo esc_url(home_url('/barrierefreiheit')); ?>">Barrierefreiheit</a></li>
        </ul>
      </div>

      <!-- =========================
           RECHTS: Träger & Unterstützer (Logos)
      ========================== -->
      <div class="col-12 col-lg-8 d-flex">
        <!-- Wrap: Block nach rechts / max Breite -->
        <div class="footer-logos-wrap">

          <!-- Träger und Unterstützer überschrift -->
          <h4 class="h6 text-uppercase mb-3 text-light fw-semibold">Träger und Unterstützer</h4>

          <!-- Logos: Scroll/Wrap (je nach Screen) -->
          <div class="footer-logos">

            <!-- Logo 1 -->
            <a href="https://www.lvr.de/de/nav_main/" target="_blank" rel="noopener">
              <img
                src="<?php echo get_stylesheet_directory_uri(); ?>/assets/logos/lvr.png"
                alt="LVR Logo"
              >
            </a>

            <!-- Logo 2 -->
            <a href="https://www.rheinischer-verein.de/" target="_blank" rel="noopener">
              <img
                src="<?php echo get_stylesheet_directory_uri(); ?>/assets/logos/nrw.png"
                alt="NRW Logo"
              >
            </a>

            <!-- Logo 3 -->
            <a href="https://sgdsued.rlp.de/" target="_blank" rel="noopener">
              <img
                src="<?php echo get_stylesheet_directory_uri(); ?>/assets/logos/rlp.png"
                alt="Rheinland-Pfalz Logo"
              >
            </a>

            <!-- Logo 4 -->
            <a href="https://denkmal.hessen.de/" target="_blank" rel="noopener">
              <img
                src="<?php echo get_stylesheet_directory_uri(); ?>/assets/logos/hessen.png"
                alt="Hessen Logo"
              >
            </a>

            <!-- Logo 5 -->
            <a
              href="https://www.schleswig-holstein.de/DE/landesregierung/ministerien-behoerden/ALSH/alsh_node.html"
              target="_blank"
              rel="noopener"
            >
              <img
                src="<?php echo get_stylesheet_directory_uri(); ?>/assets/logos/uni.png"
                alt="Schleswig-Holstein Logo"
              >
            </a>

          </div>
        </div>
      </div>
    </div>

    <!-- =========================
         FOOTER BOTTOM: Copyright
    ========================== -->
    <div class="footer-bottom text-center mt-4 pt-3 border-top border-secondary">
      <!-- Dynamisches Jahr -->
      <p class="mb-1 text-light small">© <?php echo date('Y'); ?> Landschaftsverband Rheinland (LVR)</p>

      <!-- Version (statisch) -->
      <p class="text-muted mb-0 small">Version 4.52.0</p>
    </div>

  </div>
</footer>

<!-- WP Hook: Footer Scripts (z.B. Bootstrap/Plugins) -->
<?php wp_footer(); ?>
</body>
</html>
