<?php
/* Header laden (header.php) */
get_header();

/* WordPress Loop: falls Inhalt vorhanden ist, ausgeben */
if (have_posts()) :
  while (have_posts()) :
    the_post();        // aktuellen Beitrag/Seite setzen
    the_content();     // Inhalt ausgeben (inkl. Shortcodes)
  endwhile;
endif;

/* Footer laden (footer.php) */
get_footer();
