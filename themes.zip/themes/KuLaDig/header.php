<?php
/**
 * Header
 * - Dunkelblauer Full-Width-Header (ohne Suche)
 * - Enthält Navigation + Logo
 */
?>
<!doctype html>

<html <?php language_attributes(); ?>>
<head>
  <!-- Zeichensatz aus WP -->
  <meta charset="<?php bloginfo('charset'); ?>">

  <!-- Responsive Layout -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- WP Hook: Styles/Scripts/Meta von Theme/Plugins -->
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

  <!-- Skip-Link: Accessibility (mit Tab direkt zum Content springen) -->
  <a class="skip-link screen-reader-text" href="#main">
    <?php esc_html_e('Zum Inhalt springen', 'textdomain'); ?>
  </a>

  <!-- Header: volle Breite -->
  <header class="w-100 kld-header">
    <!-- Bootstrap Navbar (dark) -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#0b1324;">

      <div class="container-fluid px-3">

        <!-- Logo / Brand Link zur Startseite -->
        <a
          class="navbar-brand d-flex align-items-center gap-2 text-decoration-none"
          style="margin-left: clamp(6.5rem, 7vw, 9rem);"
          href="<?php echo esc_url(home_url('/')); ?>"
        >
          <img
            src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/KuLaDig_Logo_Transparent_weiss.png'); ?>"
            alt="<?php bloginfo('name'); ?>"
            style="height:70px;width:auto;"
          />
        </a>

        <!-- Mobile Toggle (Burger) -->
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#primaryNav"
          aria-controls="primaryNav"
          aria-expanded="false"
          aria-label="<?php esc_attr_e('Menü öffnen', 'textdomain'); ?>"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation -->
        <div class="collapse navbar-collapse" id="primaryNav">
          <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">

            <li class="nav-item">
              <a class="nav-link" href="<?php echo esc_url(home_url('/suchen')); ?>">
                <?php esc_html_e('Suchen', 'textdomain'); ?>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo esc_url(home_url('/karte')); ?>">
                <?php esc_html_e('Karte', 'textdomain'); ?>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo esc_url(home_url('/mitmachen')); ?>">
                <?php esc_html_e('Mitmachen', 'textdomain'); ?>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo esc_url(home_url('/newsfeed')); ?>">
                <?php esc_html_e('Newsfeed', 'textdomain'); ?>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="<?php echo esc_url(home_url('/hilfe')); ?>">
                <?php esc_html_e('Hilfe', 'textdomain'); ?>
              </a>
            </li>

            <!-- Rechter Button: Anmelden -->
            <li class="nav-item nav-item-login ms-lg-2">
              <a class="kld-pill-login" href="<?php echo esc_url(home_url('/anmelden')); ?>">
                <span class="kld-pill-left" aria-hidden="true">👤</span>
                <span class="kld-pill-right">
                  <span class="kld-pill-text"><?php esc_html_e('Anmelden', 'textdomain'); ?></span>
                  <span aria-hidden="true">↗️</span>
                </span>
              </a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
  </header>

  <!-- Main Content Start -->
  <main id="main">
